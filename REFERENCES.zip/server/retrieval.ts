import fs from "node:fs";
import path from "node:path";
import {
  CitedSource,
  ClickContext,
  RagChunkRecord,
  RetrievedChunk,
  Source,
} from "../src/ai/types";

interface RagIndexFile {
  version: number;
  model: string;
  provider: string;
  dimension: number;
  dtype: "float16" | "float32";
  chunk_count: number;
  chunks: RagChunkRecord[];
}

interface DecodedChunk {
  id: string;
  sourceId: string;
  section: string;
  page: number | null;
  text: string;
  vector: Float32Array;
}

interface LoadedRagStore {
  dimension: number;
  model: string;
  chunks: DecodedChunk[];
  sourcesById: Map<string, Source>;
}

const STOPWORDS = new Set<string>([
  "the", "and", "for", "with", "that", "this", "from", "are", "was", "were",
  "have", "has", "had", "not", "but", "what", "how", "why", "when", "where",
  "can", "will", "into", "about", "over", "after", "under", "between", "their",
  "there", "been", "also", "more", "some", "such", "than", "then", "them",
  "these", "those", "which", "while", "who", "whom", "whose", "your", "ours",
]);

let cachedStore: LoadedRagStore | null = null;

/**
 * Deterministic 32-bit FNV-1a hash matching `fnv1a_32` in `scripts/build_rag_index.py`.
 */
export function fnv1a32(text: string): number {
  let h = 0x811c9dc5;
  const bytes = Buffer.from(text, "utf-8");
  for (let i = 0; i < bytes.length; i++) {
    h ^= bytes[i];
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

/**
 * Projects a query string into a unit-normalized `dim`-dimensional Float32Array
 * using signed FNV-1a feature hashing over unigrams and adjacent bigrams.
 */
export function embedQueryFastHash(text: string, dim = 768): Float32Array {
  const vec = new Float32Array(dim);
  const rawTokens = text.toLowerCase().match(/[a-z0-9\u0600-\u06ff]{2,}/g) ?? [];
  const tokens = rawTokens.filter((t) => !STOPWORDS.has(t));
  if (tokens.length === 0) {
    return vec;
  }

  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];
    const h = fnv1a32(tok);
    const bucket = h % dim;
    const sign = ((h >>> 31) & 1) === 0 ? 1.0 : -1.0;
    const weight = tok.length >= 5 ? 1.6 : 1.0;
    vec[bucket] += sign * weight;

    if (i + 1 < tokens.length) {
      const bigram = `${tok}_${tokens[i + 1]}`;
      const hb = fnv1a32(bigram);
      const bBucket = hb % dim;
      const bSign = ((hb >>> 31) & 1) === 0 ? 1.0 : -1.0;
      vec[bBucket] += bSign * 1.4;
    }
  }

  return normalizeVector(vec);
}

/**
 * Converts a 16-bit IEEE 754 half-precision integer to a 32-bit float.
 */
export function decodeFloat16Word(h: number): number {
  const sign = (h & 0x8000) >> 15;
  const exponent = (h & 0x7c00) >> 10;
  const fraction = h & 0x03ff;

  if (exponent === 0) {
    if (fraction === 0) {
      return sign === 1 ? -0.0 : 0.0;
    }
    const val = (fraction / 1024) * Math.pow(2, -14);
    return sign === 1 ? -val : val;
  }

  if (exponent === 0x1f) {
    return fraction === 0 ? (sign === 1 ? -Infinity : Infinity) : NaN;
  }

  const val = (1 + fraction / 1024) * Math.pow(2, exponent - 15);
  return sign === 1 ? -val : val;
}

/**
 * Decodes a base64-encoded float16 or float32 vector into a normalized Float32Array.
 */
export function decodeBase64Embedding(
  b64: string,
  dtype: "float16" | "float32" = "float16"
): Float32Array {
  const buf = Buffer.from(b64, "base64");
  if (dtype === "float32") {
    const len = Math.floor(buf.byteLength / 4);
    const out = new Float32Array(len);
    for (let i = 0; i < len; i++) {
      out[i] = buf.readFloatLE(i * 4);
    }
    return normalizeVector(out);
  }

  const len = Math.floor(buf.byteLength / 2);
  const out = new Float32Array(len);
  for (let i = 0; i < len; i++) {
    const word = buf.readUInt16LE(i * 2);
    out[i] = decodeFloat16Word(word);
  }
  return normalizeVector(out);
}

/**
 * Returns a unit-length L2-normalized copy of a Float32Array.
 */
export function normalizeVector(vec: Float32Array): Float32Array {
  let sumSq = 0;
  for (let i = 0; i < vec.length; i++) {
    sumSq += vec[i] * vec[i];
  }
  const norm = Math.sqrt(sumSq);
  if (norm === 0 || !Number.isFinite(norm)) {
    return vec;
  }
  const out = new Float32Array(vec.length);
  for (let i = 0; i < vec.length; i++) {
    out[i] = vec[i] / norm;
  }
  return out;
}

/**
 * Computes cosine similarity between two L2-normalized Float32Arrays.
 */
export function cosineSimilarity(a: Float32Array, b: Float32Array): number {
  if (a.length === 0 || a.length !== b.length) {
    return 0;
  }
  let dot = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
  }
  return dot;
}

/**
 * Loads `public/rag/index.json` and `public/rag/sources.json` into memory once per cold start.
 */
export function loadRagStore(options?: {
  indexPath?: string;
  sourcesPath?: string;
  forceReload?: boolean;
}): LoadedRagStore {
  if (cachedStore && !options?.forceReload && !options?.indexPath) {
    return cachedStore;
  }

  const indexPath =
    options?.indexPath ??
    path.resolve(process.cwd(), "public", "rag", "index.json");
  const sourcesPath =
    options?.sourcesPath ??
    path.resolve(process.cwd(), "public", "rag", "sources.json");

  if (!fs.existsSync(indexPath) || !fs.existsSync(sourcesPath)) {
    return {
      dimension: 0,
      model: "uninitialized",
      chunks: [],
      sourcesById: new Map<string, Source>(),
    };
  }

  const rawIndex = JSON.parse(
    fs.readFileSync(indexPath, "utf-8")
  ) as RagIndexFile;
  const rawSources = JSON.parse(
    fs.readFileSync(sourcesPath, "utf-8")
  ) as Source[];

  const sourcesById = new Map<string, Source>();
  for (const src of rawSources) {
    sourcesById.set(src.id, src);
  }

  const defaultDtype = rawIndex.dtype ?? "float16";
  const decodedChunks: DecodedChunk[] = rawIndex.chunks.map((c) => ({
    id: c.id,
    sourceId: c.source_id,
    section: c.section,
    page: c.page ?? null,
    text: c.text,
    vector: decodeBase64Embedding(c.embedding, c.dtype ?? defaultDtype),
  }));

  const loaded: LoadedRagStore = {
    dimension: rawIndex.dimension,
    model: rawIndex.model,
    chunks: decodedChunks,
    sourcesById,
  };

  if (!options?.indexPath) {
    cachedStore = loaded;
  }
  return loaded;
}

/**
 * Builds the composite retrieval query: user question + site + active layer.
 */
export function buildRetrievalQuery(
  question: string,
  clickContext?: ClickContext
): string {
  const parts: string[] = [question.trim()];
  if (clickContext?.siteId) {
    const siteDescriptive: Record<ClickContext["siteId"], string> = {
      california: "California wildfires vegetation backscatter RVI L-band SAR",
      nile_delta:
        "Nile Delta agriculture soil moisture coastal erosion land subsidence InSAR",
      himalaya:
        "Himalaya Gangotri glacier velocity ice motion cryosphere pixel offsets InSAR",
    };
    parts.push(
      `Site: ${clickContext.siteId} (${siteDescriptive[clickContext.siteId]})`
    );
  }
  if (clickContext?.activeLayer) {
    parts.push(`Active Layer: ${clickContext.activeLayer}`);
  }
  return parts.join(" | ");
}

function computeLexicalOverlapScore(query: string, text: string): number {
  const qTokens = query
    .toLowerCase()
    .split(/[^a-z0-9\u0600-\u06ff]+/)
    .filter((t) => t.length >= 3 && !STOPWORDS.has(t));
  if (qTokens.length === 0) {
    return 0;
  }
  const uniqueQ = Array.from(new Set(qTokens));
  const hay = text.toLowerCase();
  let hits = 0;
  for (const token of uniqueQ) {
    if (hay.includes(token)) {
      hits += 1;
    }
  }
  return hits / uniqueQ.length;
}

export interface RetrieveOptions {
  question: string;
  clickContext?: ClickContext;
  queryEmbedding?: Float32Array | number[];
  topK?: number;
  minScore?: number;
  indexPath?: string;
  sourcesPath?: string;
}

export interface RetrievalResult {
  query: string;
  chunks: RetrievedChunk[];
  citedSources: CitedSource[];
  usedLexicalFallback: boolean;
}

/**
 * Retrieves top-k chunks by cosine similarity with a configurable similarity floor
 * and deduplication by `(sourceId, section)`.
 */
export function retrieveTopChunks(options: RetrieveOptions): RetrievalResult {
  const topK = options.topK ?? 5;
  const minScore = options.minScore ?? 0.28;
  const store = loadRagStore({
    indexPath: options.indexPath,
    sourcesPath: options.sourcesPath,
  });

  const compositeQuery = buildRetrievalQuery(
    options.question,
    options.clickContext
  );

  if (store.chunks.length === 0) {
    return {
      query: compositeQuery,
      chunks: [],
      citedSources: [],
      usedLexicalFallback: false,
    };
  }

  const isFastHashIndex = store.model === "fast-hash-768";
  let queryVec: Float32Array | null = null;

  if (options.queryEmbedding && !isFastHashIndex) {
    const rawArr =
      options.queryEmbedding instanceof Float32Array
        ? options.queryEmbedding
        : new Float32Array(options.queryEmbedding);
    if (rawArr.length === store.dimension) {
      queryVec = normalizeVector(rawArr);
    }
  } else if (isFastHashIndex) {
    queryVec = embedQueryFastHash(compositeQuery, store.dimension);
  }

  const usedLexicalFallback = queryVec === null;
  const effectiveFloor = isFastHashIndex
    ? Math.min(minScore, 0.08)
    : usedLexicalFallback
      ? Math.min(minScore, 0.15)
      : minScore;

  const scored: Array<{ chunk: DecodedChunk; score: number }> = [];
  for (const chunk of store.chunks) {
    const score = queryVec
      ? cosineSimilarity(queryVec, chunk.vector)
      : computeLexicalOverlapScore(
          compositeQuery,
          `${chunk.section} ${chunk.text}`
        );
    if (score >= effectiveFloor) {
      scored.push({ chunk, score });
    }
  }

  scored.sort((a, b) => b.score - a.score);

  const seenSourceSections = new Set<string>();
  const selectedChunks: RetrievedChunk[] = [];
  const citedSources: CitedSource[] = [];

  for (const item of scored) {
    if (selectedChunks.length >= topK) {
      break;
    }
    const dedupeKey = `${item.chunk.sourceId}::${item.chunk.section.trim().toLowerCase()}`;
    if (seenSourceSections.has(dedupeKey)) {
      continue;
    }
    seenSourceSections.add(dedupeKey);

    const srcMeta = store.sourcesById.get(item.chunk.sourceId) ?? {
      id: item.chunk.sourceId,
      title: item.chunk.sourceId,
      url: "",
      attribution: "NASA / JPL / ASF",
    };

    const citationIndex = selectedChunks.length + 1;
    const citationTag = `S${citationIndex}`;

    selectedChunks.push({
      id: item.chunk.id,
      citationTag,
      sourceId: srcMeta.id,
      sourceTitle: srcMeta.title,
      sourceUrl: srcMeta.url,
      attribution: srcMeta.attribution,
      section: item.chunk.section,
      page: item.chunk.page,
      text: item.chunk.text,
      score: Number(item.score.toFixed(4)),
    });

    citedSources.push({
      id: srcMeta.id,
      title: srcMeta.title,
      url: srcMeta.url,
      attribution: srcMeta.attribution,
      citationTag,
      section: item.chunk.section,
      page: item.chunk.page,
      score: Number(item.score.toFixed(4)),
    });
  }

  return {
    query: compositeQuery,
    chunks: selectedChunks,
    citedSources,
    usedLexicalFallback,
  };
}