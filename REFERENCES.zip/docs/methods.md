# Dancing with the SARs: Team Processing Pipeline, Formulas, and Limitations

## 1. Overview of the Static Pre-Processing Architecture
To keep the web application fast and verifiable, raw NISAR HDF5 products (Level-2 GCOV, GUNW, GOFF, and Level-3 SME2) are processed offline into:
- `catalog.json`: Site bounding boxes, available acquisition dates, orbit tracks, pass directions (`ASCENDING`/`DESCENDING`), and site-specific methodological caveats (`siteNotes`).
- `timeseries/points.json`: Pre-extracted time-series arrays (`dates`, `hv_db`, `coh`, `disp_mm`) and single-date layer metrics (`values`) for sampled map locations.
- Map tiles and cloud-optimized layers for MapLibre GL visualization (`hh_db`, `hv_db`, `rvi`, `coherence`, `change`, `los_disp_mm`, `disp_rate_mm_yr`, `velocity_m_yr`, `soil_moisture`).

The AI assistant never reads raster pixels directly; instead, clicking a map point injects a validated `ClickContext` JSON payload containing the exact pre-computed metrics at that coordinate.

## 2. Case-Study Site Pipelines & Physical Formulas

### Site A: California Wildfires & Vegetation Change (`california`)
- **Primary Products**: NISAR Level-2 Geocoded Polarimetric Covariance (`GCOV`) and Level-2 Unwrapped Interferogram (`GUNW`) coherence.
- **Backscatter Conversion**: Linear covariance matrix terms ($\gamma^0_{HH}$ and $\gamma^0_{HV}$) are converted to decibels:
  `hh_db = 10 * log10(gamma0_HH)` and `hv_db = 10 * log10(gamma0_HV)`.
- **Radar Vegetation Index (RVI)**: Computed in linear power scale before display:
  `RVI = (4 * HV_linear) / (HH_linear + HV_linear)` for dual-pol scenes.
  Unburned dense chaparral and forest canopies exhibit stronger cross-polarized volume scattering (`hv_db` and `rvi`), whereas wildfire burn scars show a sharp drop in `hv_db` and `rvi` as canopy structure is removed.
- **Limitations**: Steep topography introduces local incidence-angle variations and radar shadow/layover even after gamma-naught terrain flattening.

### Site B: Nile Delta Agriculture, Soil Moisture, Coastline & Subsidence (`nile_delta`)
- **Primary Products**: Level-2 `GCOV` (crop structure), Level-3 `SME2` (volumetric soil moisture), and Level-2 `GUNW` (interferometric phase displacement and coherence).
- **Physics & InSAR Displacement**:
  - Irrigation and rainfall increase the soil's **dielectric constant**, raising L-band backscatter (`hh_db`) and retrieved volumetric `soil_moisture` ($m^3/m^3$).
  - Line-of-Sight (LOS) displacement (`los_disp_mm`) is derived from unwrapped interferometric phase ($\Delta \phi$) at L-band wavelength ($\lambda \approx 24.2\text{ cm}$):
    `los_disp_mm = - (lambda_mm / (4 * pi)) * delta_phi_unwrapped`.
  - Negative `los_disp_mm` or `disp_rate_mm_yr` indicates ground motion away from the radar (consistent with sediment compaction and groundwater extraction).
- **Limitations**: Rapid seasonal crop growth causes temporal decorrelation (low `coherence`), and coastal Mediterranean water vapor gradients introduce tropospheric phase delay noise. All displacement values are relative to a stable reference pixel.

### Site C: Himalaya Gangotri Glacier (`himalaya`)
- **Primary Products**: Level-2 Geocoded Pixel Offsets (`GOFF`) and `GCOV`.
- **Glacier Surface Velocity (`velocity_m_yr`)**: Because valley glaciers move tens of meters per year, 12-day interferometric phase often aliases and decorrelates (`coherence < 0.30`). We derive horizontal ice speed (`velocity_m_yr`) from sub-pixel cross-correlation of radar amplitude/feature patches (`GOFF` along-track and slant-range offsets) scaled to meters per year.
- **Limitations**: Some high-mountain acquisitions are single-polarization (`HH`-only), so `hv_db` and `rvi` are `null`. Steep glacial valley walls cause radar layover and shadow.

## 3. Global Validity & Uncertainty Guardrails
- **Short Record Warning**: When `datesCount < 4` or `recordDays < 45`, seasonal cycles, tropospheric delay, and ionospheric phase screens cannot be separated from long-term deformation or vegetation trends.
- **Non-Operational Status**: All layers in "Dancing with the SARs" are scientific visualization products and must never be used for emergency evacuation orders, structural safety certification, or operational hazard forecasting.