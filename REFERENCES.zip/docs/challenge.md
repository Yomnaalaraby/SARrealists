# NASA Space Apps Challenge: Dancing with the SARs

## Challenge Statement & Objective
Synthetic Aperture Radar (SAR) sensors—led by the joint NASA-ISRO Synthetic Aperture Radar (NISAR) mission—image Earth's changing ecosystems, cryosphere, and solid-earth deformation day and night through clouds, smoke, and rain.

The objective of "Dancing with the SARs" is to make complex multi-polarization (HH, HV) and interferometric (InSAR / pixel-offset) radar time-series accessible and scientifically rigorous for diverse audiences:
- **Scientists** analyzing backscatter (dB), Radar Vegetation Index (RVI), interferometric coherence, and line-of-sight (LOS) deformation.
- **Decision Makers** evaluating landscape shifts, agricultural moisture trends, and data limitations without misinterpreting research layers as operational hazard directives.
- **Students** connecting satellite observations to microwave physics (surface roughness, volume scattering, and dielectric constant).
- **Space Enthusiasts** exploring how 24 cm L-band radar waves reveal hidden movements of forests, river deltas, and mountain glaciers.
