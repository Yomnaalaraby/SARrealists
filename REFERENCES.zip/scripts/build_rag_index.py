#!/usr/bin/env python3
"""
Offline RAG Index Builder for "Dancing with the SARs" (NASA Space Apps Challenge).

Features:
  - Reuses cached chunks in `public/rag/.chunks_cache.json` (zero re-downloading).
  - Supports `--provider fast` (deterministic 768-dim FNV-1a unigram/bigram hashing
    in pure NumPy: builds `index.json` in < 0.5s with zero API calls).
  - When `--provider gemini` is used and hits HTTP 429 (free-tier quota exceeded),
    automatically falls back to `fast-hash-768` so `public/rag/index.json` and
    `public/rag/sources.json` are always written immediately (pass `--wait-on-429`
    if you prefer sleeping 62s per batch instead).

Usage:
  python scripts/build_rag_index.py --provider fast --dtype float16
  python scripts/build_rag_index.py --provider gemini --dtype float16
"""

from __future__ import annotations

import argparse
import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
import io
import json
import logging
import os
from pathlib import Path
import re
import ssl
import sys
import time
from typing import Any, Callable, Dict, List, Optional, Tuple
import urllib.error
import urllib.request

import yaml

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_SOURCES_YAML = PROJECT_ROOT / "scripts" / "sources.yaml"
DEFAULT_INDEX_OUT = PROJECT_ROOT / "public" / "rag" / "index.json"
DEFAULT_SOURCES_OUT = PROJECT_ROOT / "public" / "rag" / "sources.json"
DEFAULT_CHUNKS_CACHE = PROJECT_ROOT / "public" / "rag" / ".chunks_cache.json"
DEFAULT_EMBEDDINGS_CACHE = PROJECT_ROOT / "public" / "rag" / ".embeddings_cache.json"
DEFAULT_REFERENCES_OUT = PROJECT_ROOT / "REFERENCES.md"

USER_AGENT = (
    "DancingWithTheSARs-RAGBuilder/1.4 "
    "(NASA Space Apps Challenge; Grounded NISAR Educational Assistant)"
)

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "are", "was", "were",
    "have", "has", "had", "not", "but", "what", "how", "why", "when", "where",
    "can", "will", "into", "about", "over", "after", "under", "between", "their",
    "there", "been", "also", "more", "some", "such", "than", "then", "them",
    "these", "those", "which", "while", "who", "whom", "whose", "your", "ours",
}

_TIKTOKEN_ENC: Any = None
_TIKTOKEN_LOADED = False


@dataclass
class RawSection:
    section: str
    page: Optional[int]
    text: str


@dataclass
class ChunkItem:
    id: str
    source_id: str
    section: str
    page: Optional[int]
    text: str
    token_count: int


def get_tiktoken_encoder() -> Any:
    global _TIKTOKEN_ENC, _TIKTOKEN_LOADED
    if not _TIKTOKEN_LOADED:
        _TIKTOKEN_LOADED = True
        try:
            import tiktoken  # type: ignore

            _TIKTOKEN_ENC = tiktoken.get_encoding("cl100k_base")
        except Exception:
            _TIKTOKEN_ENC = None
    return _TIKTOKEN_ENC


def count_tokens(text: str) -> int:
    enc = get_tiktoken_encoder()
    if enc is not None:
        return len(enc.encode(text))
    words = re.findall(r"\S+", text)
    return int(round(len(words) * 1.3))


def chunk_section_text(
    text: str,
    min_tokens: int = 500,
    max_tokens: int = 800,
    overlap_tokens: int = 100,
) -> List[str]:
    cleaned = re.sub(r"[ \t]+", " ", text).strip()
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    if not cleaned:
        return []

    target_tokens = max(min_tokens, min(650, max_tokens))
    step_tokens = max(1, target_tokens - overlap_tokens)
    enc = get_tiktoken_encoder()

    if enc is not None:
        token_ids = enc.encode(cleaned)
        if len(token_ids) <= max_tokens:
            return [cleaned]

        chunks: List[str] = []
        start = 0
        while start < len(token_ids):
            end = min(start + target_tokens, len(token_ids))
            if len(token_ids) - end < overlap_tokens and end < len(token_ids):
                end = len(token_ids)
            chunk_str = enc.decode(token_ids[start:end]).strip()
            if chunk_str:
                chunks.append(chunk_str)
            if end >= len(token_ids):
                break
            start += step_tokens
        return chunks

    words = cleaned.split()
    max_words = int(max_tokens / 1.3)
    target_words = int(target_tokens / 1.3)
    overlap_words = int(overlap_tokens / 1.3)
    step_words = max(1, target_words - overlap_words)

    if len(words) <= max_words:
        return [cleaned]

    chunks = []
    start = 0
    while start < len(words):
        end = min(start + target_words, len(words))
        if len(words) - end < overlap_words and end < len(words):
            end = len(words)
        chunk_str = " ".join(words[start:end]).strip()
        if chunk_str:
            chunks.append(chunk_str)
        if end >= len(words):
            break
        start += step_words
    return chunks


def fnv1a_32(text: str) -> int:
    """Deterministic 32-bit FNV-1a hash matching server/retrieval.ts."""
    h = 0x811C9DC5
    for b in text.encode("utf-8"):
        h ^= b
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h


def embed_text_fast_hash(text: str, dim: int = 768) -> Any:
    """
    Projects text into a unit-normalized `dim`-dimensional float32 vector using
    signed FNV-1a feature hashing over unigrams and adjacent bigrams.
    Matches `embedQueryFastHash` in `server/retrieval.ts`.
    """
    import numpy as np  # type: ignore

    vec = np.zeros(dim, dtype=np.float32)
    raw_tokens = re.findall(r"[a-z0-9\u0600-\u06ff]{2,}", text.lower())
    tokens = [t for t in raw_tokens if t not in STOPWORDS]
    if not tokens:
        return vec

    for i, tok in enumerate(tokens):
        h = fnv1a_32(tok)
        bucket = h % dim
        sign = 1.0 if ((h >> 31) & 1) == 0 else -1.0
        weight = 1.6 if len(tok) >= 5 else 1.0
        vec[bucket] += sign * weight

        if i + 1 < len(tokens):
            bigram = f"{tok}_{tokens[i + 1]}"
            hb = fnv1a_32(bigram)
            b_bucket = hb % dim
            b_sign = 1.0 if ((hb >> 31) & 1) == 0 else -1.0
            vec[b_bucket] += b_sign * 1.4

    norm = float(np.linalg.norm(vec))
    if norm > 0.0:
        vec /= norm
    return vec


def build_fast_hash_embedder(
    dim: int = 768,
) -> Tuple[str, Callable[[List[ChunkItem]], Any]]:
    import numpy as np  # type: ignore

    def embed_chunks(chunks: List[ChunkItem]) -> Any:
        rows = [
            embed_text_fast_hash(f"{c.section}\n\n{c.text}", dim=dim)
            for c in chunks
        ]
        return np.asarray(rows, dtype=np.float32)

    return "fast-hash-768", embed_chunks


def verify_and_fetch_url(
    url: str,
    expected_type: str,
    verify_only: bool = False,
    timeout: int = 20,
) -> Tuple[bool, str, Optional[bytes]]:
    headers: Dict[str, str] = {"User-Agent": USER_AGENT}
    earthdata_token = os.environ.get("EARTHDATA_TOKEN", "").strip()
    if earthdata_token and "earthdatacloud.nasa.gov" in url:
        headers["Authorization"] = f"Bearer {earthdata_token}"

    req = urllib.request.Request(url, headers=headers, method="GET")
    ssl_ctx = ssl.create_default_context()

    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl_ctx) as resp:
            status_code = resp.getcode() or 200
            if status_code != 200:
                return False, f"HTTP {status_code} from {url}", None

            content_type = (resp.headers.get("Content-Type") or "").lower()
            content_length_hdr = resp.headers.get("Content-Length")

            if verify_only:
                head_bytes = resp.read(1024)
                if expected_type == "pdf":
                    is_pdf_bytes = head_bytes[:4] == b"%PDF"
                    if "application/pdf" not in content_type and not is_pdf_bytes:
                        return (
                            False,
                            f"Expected PDF but got Content-Type '{content_type}'",
                            None,
                        )
                size_info = (
                    f"{int(content_length_hdr) / 1024:.1f} KB"
                    if content_length_hdr and content_length_hdr.isdigit()
                    else "stream verified"
                )
                return True, f"OK ({size_info})", head_bytes

            content_bytes = resp.read()
            if expected_type == "pdf":
                is_pdf_bytes = content_bytes[:4] == b"%PDF"
                if "application/pdf" not in content_type and not is_pdf_bytes:
                    return (
                        False,
                        f"Expected PDF but got Content-Type '{content_type}'",
                        None,
                    )
            return True, f"OK ({len(content_bytes) / 1024:.1f} KB)", content_bytes

    except urllib.error.HTTPError as exc:
        return False, f"HTTP {exc.code}: {exc.reason}", None
    except urllib.error.URLError as exc:
        return False, f"URL error: {exc.reason}", None
    except Exception as exc:
        return False, f"Request error: {exc}", None


def extract_sections_from_html(
    html_bytes: bytes, default_title: str
) -> List[RawSection]:
    from bs4 import BeautifulSoup  # type: ignore

    soup = BeautifulSoup(html_bytes, "html.parser")
    for noisy_tag in soup(
        ["script", "style", "nav", "footer", "header", "noscript", "svg"]
    ):
        noisy_tag.decompose()

    main_container = (
        soup.find("main")
        or soup.find("article")
        or soup.find("div", {"role": "main"})
        or soup.body
        or soup
    )

    sections: List[RawSection] = []
    current_heading = default_title
    current_paragraphs: List[str] = []

    for element in main_container.find_all(
        ["h1", "h2", "h3", "h4", "p", "li", "td", "pre"]
    ):
        tag_name = element.name.lower() if element.name else ""
        text = re.sub(r"\s+", " ", element.get_text(" ", strip=True)).strip()
        if not text:
            continue

        if tag_name in {"h1", "h2", "h3", "h4"}:
            if current_paragraphs:
                joined = "\n\n".join(current_paragraphs).strip()
                if len(joined) >= 80:
                    sections.append(
                        RawSection(section=current_heading, page=None, text=joined)
                    )
                current_paragraphs = []
            current_heading = text[:160]
        else:
            if len(text) >= 25:
                current_paragraphs.append(text)

    if current_paragraphs:
        joined = "\n\n".join(current_paragraphs).strip()
        if len(joined) >= 80:
            sections.append(
                RawSection(section=current_heading, page=None, text=joined)
            )

    return sections


def detect_pdf_page_heading(page_text: str, fallback_heading: str) -> str:
    for line in page_text.splitlines()[:8]:
        clean = line.strip()
        if 4 <= len(clean) <= 110 and not clean.isdigit():
            if "california institute of technology" in clean.lower():
                continue
            return clean
    return fallback_heading


def extract_sections_from_pdf(
    pdf_bytes: bytes, default_title: str, max_pages: Optional[int] = None
) -> List[RawSection]:
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    from pypdf import PdfReader  # type: ignore

    reader = PdfReader(io.BytesIO(pdf_bytes), strict=False)
    sections: List[RawSection] = []
    total_pages = len(reader.pages)
    limit = min(total_pages, max_pages) if max_pages else total_pages

    last_heading = default_title
    for idx in range(limit):
        page_num = idx + 1
        try:
            raw_text = reader.pages[idx].extract_text() or ""
        except Exception:
            continue
        cleaned = re.sub(r"[ \t]+", " ", raw_text).strip()
        if len(cleaned) < 60:
            continue
        heading = detect_pdf_page_heading(cleaned, last_heading)
        last_heading = heading
        sections.append(RawSection(section=heading, page=page_num, text=cleaned))

    return sections


def extract_sections_from_markdown(
    md_text: str, default_title: str
) -> List[RawSection]:
    sections: List[RawSection] = []
    current_heading = default_title
    buffer: List[str] = []

    for line in md_text.splitlines():
        heading_match = re.match(r"^(#{1,4})\s+(.+)$", line.strip())
        if heading_match:
            if buffer:
                body = "\n".join(buffer).strip()
                if body:
                    sections.append(
                        RawSection(section=current_heading, page=None, text=body)
                    )
                buffer = []
            current_heading = heading_match.group(2).strip()[:160]
        else:
            buffer.append(line)

    if buffer:
        body = "\n".join(buffer).strip()
        if body:
            sections.append(
                RawSection(section=current_heading, page=None, text=body)
            )

    return sections


def parse_retry_seconds(err_body: str, default_wait: int = 62) -> int:
    match = re.search(r'"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"', err_body)
    if not match:
        match = re.search(r"retry in (\d+(?:\.\d+)?)s", err_body, re.IGNORECASE)
    if match:
        return max(5, int(float(match.group(1))) + 3)
    return default_wait


def build_gemini_embedder(
    model_name: str,
    output_dim: int = 768,
    batch_size: int = 25,
    wait_on_429: bool = False,
) -> Tuple[str, Callable[[List[ChunkItem]], Tuple[str, Any]]]:
    """
    Embeds chunks with Gemini REST API (`GEMINI_API_KEY`).
    If HTTP 429 occurs and `wait_on_429` is False (default), immediately falls back
    to `fast-hash-768` so the index build completes in < 1 second.
    """
    import numpy as np  # type: ignore

    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        print(
            "[WARN] GEMINI_API_KEY is not set; using deterministic fast-hash-768 embedder.",
            flush=True,
        )
        fast_name, fast_fn = build_fast_hash_embedder(dim=output_dim)
        return fast_name, lambda ch: (fast_name, fast_fn(ch))

    ssl_ctx = ssl.create_default_context()
    active_model = (
        model_name if model_name.startswith("models/") else f"models/{model_name}"
    )

    def send_batch_request(
        target_model: str, batch_texts: List[str], include_dim: bool = True
    ) -> List[List[float]]:
        endpoint = f"https://generativelanguage.googleapis.com/v1beta/{target_model}:batchEmbedContents"
        requests_payload = []
        for t in batch_texts:
            item_req: Dict[str, Any] = {
                "model": target_model,
                "content": {"parts": [{"text": t}]},
            }
            if include_dim and output_dim > 0:
                item_req["outputDimensionality"] = output_dim
            requests_payload.append(item_req)

        body_bytes = json.dumps({"requests": requests_payload}).encode("utf-8")
        req = urllib.request.Request(
            endpoint,
            data=body_bytes,
            headers={
                "Content-Type": "application/json",
                "x-goog-api-key": api_key,
                "User-Agent": USER_AGENT,
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60, context=ssl_ctx) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return [item["values"] for item in data.get("embeddings", [])]

    def embed_chunks(chunks: List[ChunkItem]) -> Tuple[str, Any]:
        nonlocal active_model
        cached_vectors: Dict[str, List[float]] = {}
        if DEFAULT_EMBEDDINGS_CACHE.exists():
            try:
                raw_cache = json.loads(
                    DEFAULT_EMBEDDINGS_CACHE.read_text(encoding="utf-8")
                )
                if raw_cache.get("dim") == output_dim:
                    cached_vectors = raw_cache.get("vectors", {})
            except Exception:
                cached_vectors = {}

        missing_chunks = [c for c in chunks if c.id not in cached_vectors]
        total_missing = len(missing_chunks)

        if total_missing > 0:
            total_batches = (total_missing + batch_size - 1) // batch_size
            for batch_idx, start in enumerate(
                range(0, total_missing, batch_size), start=1
            ):
                batch_items = missing_chunks[start : start + batch_size]
                batch_texts = [f"{c.section}\n\n{c.text}" for c in batch_items]

                while True:
                    try:
                        vecs = send_batch_request(
                            active_model, batch_texts, include_dim=True
                        )
                        break
                    except urllib.error.HTTPError as exc:
                        err_body = exc.read().decode("utf-8", errors="replace")
                        if exc.code == 429:
                            if not wait_on_429:
                                print(
                                    "\n[QUOTA 429] Gemini free-tier embedding quota reached. "
                                    "Switching to instant deterministic 'fast-hash-768' embedder "
                                    "(pass --wait-on-429 to sleep and wait for Gemini quota reset).",
                                    flush=True,
                                )
                                fast_name, fast_fn = build_fast_hash_embedder(
                                    dim=output_dim
                                )
                                return fast_name, fast_fn(chunks)

                            wait_sec = parse_retry_seconds(err_body, default_wait=62)
                            print(
                                f"     [RATE LIMIT 429] Waiting {wait_sec}s for quota reset...",
                                flush=True,
                            )
                            time.sleep(wait_sec)
                            continue
                        raise RuntimeError(
                            f"Gemini embedding API returned HTTP {exc.code}: {err_body[:300]}"
                        ) from exc

                for c_item, v_vals in zip(batch_items, vecs):
                    cached_vectors[c_item.id] = v_vals

                DEFAULT_EMBEDDINGS_CACHE.parent.mkdir(parents=True, exist_ok=True)
                DEFAULT_EMBEDDINGS_CACHE.write_text(
                    json.dumps(
                        {
                            "model": active_model,
                            "dim": output_dim,
                            "vectors": cached_vectors,
                        }
                    ),
                    encoding="utf-8",
                )
                print(
                    f"     -> Embedded batch {batch_idx}/{total_batches} "
                    f"({len(cached_vectors)}/{len(chunks)} chunks) using {active_model}",
                    flush=True,
                )
                if batch_idx < total_batches:
                    time.sleep(2.0)

        ordered_vectors = [cached_vectors[c.id] for c in chunks]
        matrix = np.asarray(ordered_vectors, dtype=np.float32)
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return active_model, matrix / norms

    return active_model, embed_chunks


def build_local_embedder(
    model_name: str,
) -> Tuple[str, Callable[[List[ChunkItem]], Tuple[str, Any]]]:
    import numpy as np  # type: ignore
    from sentence_transformers import SentenceTransformer  # type: ignore

    model = SentenceTransformer(model_name)

    def embed_chunks(chunks: List[ChunkItem]) -> Tuple[str, Any]:
        texts = [f"{c.section}\n\n{c.text}" for c in chunks]
        vecs = model.encode(
            texts,
            batch_size=32,
            show_progress_bar=True,
            normalize_embeddings=True,
        )
        return model_name, np.asarray(vecs, dtype=np.float32)

    return model_name, embed_chunks


def encode_vector_base64(vec: Any, dtype: str) -> str:
    import numpy as np  # type: ignore

    target_dtype = np.dtype("<f2") if dtype == "float16" else np.dtype("<f4")
    casted = vec.astype(target_dtype)
    return base64.b64encode(casted.tobytes()).decode("ascii")


def ensure_starter_local_docs() -> None:
    docs_dir = PROJECT_ROOT / "docs"
    docs_dir.mkdir(parents=True, exist_ok=True)

    challenge_path = docs_dir / "challenge.md"
    if not challenge_path.exists():
        challenge_path.write_text(
            "# NASA Space Apps Challenge: Dancing with the SARs\n\n"
            "## Challenge Overview\n"
            "Synthetic Aperture Radar (SAR) sensors such as the joint NASA-ISRO SAR (NISAR) "
            "mission observe Earth's dynamic surface through clouds, smoke, and darkness. "
            "This project translates dual-polarization L-band and S-band SAR observations "
            "into interactive, grounded visual stories for scientists, decision makers, "
            "students, and space enthusiasts.\n",
            encoding="utf-8",
        )

    methods_path = docs_dir / "methods.md"
    if not methods_path.exists():
        methods_path.write_text(
            "# Dancing with the SARs: Processing Pipeline and Limitations\n\n"
            "## Case Study Sites and Layers\n"
            "1. **California (Wildfires & Vegetation)**: Uses L-band HH and HV backscatter (dB) "
            "from GCOV products and Radar Vegetation Index (`RVI = 4*HV / (HH + HV)` in linear power) "
            "to track canopy loss and post-fire recovery.\n"
            "2. **Nile Delta (Agriculture, Soil Moisture, Subsidence & Coastline)**: Combines "
            "polarimetric backscatter, SME2 soil moisture estimates, and GUNW unwrapped phase "
            "line-of-sight displacement (`los_disp_mm`, `disp_rate_mm_yr`) with coherence masking.\n"
            "3. **Himalaya Gangotri Glacier**: Tracks rapid ice flow (`velocity_m_yr`) using "
            "GOFF pixel offset tracking where fast movement decorrelates 12-day interferometric phase.\n\n"
            "## Methodological Limitations\n"
            "- When `datesCount` is small (fewer than 4 scenes) or `recordDays` is under 45 days, "
            "tropospheric, ionospheric, and speckle noise cannot be separated from long-term signal.\n"
            "- Low interferometric coherence (below 0.35) indicates phase unwrapping unreliability.\n"
            "- All map layers are research demonstrations, never operational hazard or evacuation orders.\n",
            encoding="utf-8",
        )


def write_references_md(sources_cfg: List[Dict[str, Any]], out_path: Path) -> None:
    lines: List[str] = [
        "# External References & Official Data Sources",
        "",
        "Generated automatically from `scripts/sources.yaml` for the **Dancing with the SARs** NASA Space Apps Challenge submission.",
        "",
        "## Ingested Official NISAR & SAR Documentation",
        "",
    ]

    for idx, src in enumerate(sources_cfg, start=1):
        display_url = src.get("reference_url") or src["url"]
        status = (
            "Ingested / Enabled"
            if src.get("enabled", True)
            else "Reference Only"
        )
        lines.append(f"{idx}. **{src['title']}** (`{src['id']}`)")
        lines.append(f"   - **URL / Path**: {display_url}")
        lines.append(
            f"   - **Attribution / License**: {src.get('attribution', 'NASA / JPL / ASF')}"
        )
        lines.append(f"   - **Status**: {status}")
        if src.get("notes"):
            lines.append(f"   - **Notes**: {src['notes']}")
        lines.append("")

    out_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build RAG index and REFERENCES.md from scripts/sources.yaml"
    )
    parser.add_argument("--sources", type=Path, default=DEFAULT_SOURCES_YAML)
    parser.add_argument("--index-out", type=Path, default=DEFAULT_INDEX_OUT)
    parser.add_argument("--sources-out", type=Path, default=DEFAULT_SOURCES_OUT)
    parser.add_argument("--references-out", type=Path, default=DEFAULT_REFERENCES_OUT)
    parser.add_argument(
        "--provider",
        choices=["gemini", "fast", "local"],
        default=os.environ.get("RAG_EMBEDDING_PROVIDER", "fast"),
        help="Embedding provider: 'fast' (instant 768-dim FNV-1a hash), 'gemini' (API), or 'local' (sentence-transformers)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=os.environ.get("GEMINI_EMBEDDING_MODEL", "gemini-embedding-001"),
    )
    parser.add_argument("--dim", type=int, default=768)
    parser.add_argument("--batch-size", type=int, default=25)
    parser.add_argument("--dtype", choices=["float16", "float32"], default="float16")
    parser.add_argument("--max-chunks", type=int, default=2500)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--init-docs", action="store_true")
    parser.add_argument("--refresh-sources", action="store_true")
    parser.add_argument(
        "--wait-on-429",
        action="store_true",
        help="Wait 62s on Gemini 429 rate-limit instead of auto-switching to fast-hash-768",
    )
    parser.add_argument("--workers", type=int, default=6)
    args = parser.parse_args()

    ensure_starter_local_docs()

    if not args.sources.exists():
        print(f"[ERROR] sources.yaml not found at {args.sources}", file=sys.stderr)
        return 1

    cfg = yaml.safe_load(args.sources.read_text(encoding="utf-8"))
    sources_list: List[Dict[str, Any]] = cfg.get("sources", [])

    write_references_md(sources_list, args.references_out)
    print(f"[INFO] Generated {args.references_out}", flush=True)

    all_chunks: List[ChunkItem] = []
    ingested_sources: List[Dict[str, str]] = []

    if (
        not args.verify_only
        and not args.refresh_sources
        and DEFAULT_CHUNKS_CACHE.exists()
    ):
        try:
            cached_data = json.loads(
                DEFAULT_CHUNKS_CACHE.read_text(encoding="utf-8")
            )
            all_chunks = [
                ChunkItem(**c) for c in cached_data.get("chunks", [])
            ][: args.max_chunks]
            ingested_sources = cached_data.get("sources", [])
            if all_chunks and ingested_sources:
                print(
                    f"[CACHE] Reusing {len(all_chunks)} extracted chunks from {DEFAULT_CHUNKS_CACHE}",
                    flush=True,
                )
        except Exception:
            all_chunks = []
            ingested_sources = []

    if not all_chunks:
        verification_failures: List[Tuple[str, str, str]] = []
        todo_skipped: List[Tuple[str, str]] = []
        active_sources: List[Dict[str, Any]] = []

        for src in sources_list:
            src_id = str(src["id"])
            url = str(src["url"])
            enabled = bool(src.get("enabled", True))
            if not enabled or src.get("todo") or url.startswith("TODO"):
                todo_skipped.append((src_id, url))
                print(
                    f"[TODO/SKIP] {src_id}: Marked as unverified TODO ({url})",
                    flush=True,
                )
            else:
                active_sources.append(src)

        print(
            f"[INFO] Checking {len(active_sources)} active sources with {args.workers} threads...",
            flush=True,
        )

        fetch_results: Dict[str, Tuple[bool, str, Optional[bytes]]] = {}

        def fetch_worker(
            src_item: Dict[str, Any]
        ) -> Tuple[str, bool, str, Optional[bytes]]:
            s_id = str(src_item["id"])
            s_url = str(src_item["url"])
            s_type = str(src_item.get("type", "html")).lower()
            if s_type == "markdown" or not s_url.startswith(("http://", "https://")):
                local_path = PROJECT_ROOT / s_url
                if not local_path.exists():
                    return s_id, False, f"Local file missing at {local_path}", None
                data = local_path.read_bytes()
                return s_id, True, f"OK local ({len(data)} bytes)", data

            ok, reason, data = verify_and_fetch_url(
                s_url, s_type, verify_only=args.verify_only
            )
            return s_id, ok, reason, data

        with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
            future_map = {pool.submit(fetch_worker, s): s for s in active_sources}
            for fut in as_completed(future_map):
                src_meta = future_map[fut]
                s_id, ok, reason, data = fut.result()
                fetch_results[s_id] = (ok, reason, data)
                s_url = str(src_meta["url"])
                if ok:
                    print(f"[OK]   {s_id} -> {reason}", flush=True)
                else:
                    print(f"[FAIL] {s_id} ({s_url}) -> {reason}", flush=True)
                    verification_failures.append((s_id, s_url, reason))

        if args.verify_only:
            return 0

        for src in active_sources:
            src_id = str(src["id"])
            title = str(src["title"])
            url = str(src["url"])
            src_type = str(src.get("type", "html")).lower()
            attribution = str(src.get("attribution", "NASA / JPL / ASF"))
            max_pages = src.get("max_pages")

            ok, _, content_bytes = fetch_results.get(src_id, (False, "", None))
            if not ok or content_bytes is None:
                continue

            raw_sections: List[RawSection] = []
            if src_type == "markdown" or not url.startswith(("http://", "https://")):
                md_text = content_bytes.decode("utf-8", errors="replace")
                raw_sections = extract_sections_from_markdown(md_text, title)
            elif src_type == "pdf":
                raw_sections = extract_sections_from_pdf(
                    content_bytes, title, max_pages=max_pages
                )
            else:
                raw_sections = extract_sections_from_html(content_bytes, title)

            source_chunk_count = 0
            for sec in raw_sections:
                pieces = chunk_section_text(
                    sec.text, min_tokens=500, max_tokens=800, overlap_tokens=100
                )
                for piece in pieces:
                    if len(all_chunks) >= args.max_chunks:
                        break
                    source_chunk_count += 1
                    chunk_id = f"{src_id}#c{source_chunk_count:04d}"
                    all_chunks.append(
                        ChunkItem(
                            id=chunk_id,
                            source_id=src_id,
                            section=sec.section,
                            page=sec.page,
                            text=piece,
                            token_count=count_tokens(piece),
                        )
                    )
                if len(all_chunks) >= args.max_chunks:
                    break

            if source_chunk_count > 0:
                ingested_sources.append(
                    {
                        "id": src_id,
                        "title": title,
                        "url": url,
                        "attribution": attribution,
                    }
                )

        if all_chunks:
            DEFAULT_CHUNKS_CACHE.parent.mkdir(parents=True, exist_ok=True)
            DEFAULT_CHUNKS_CACHE.write_text(
                json.dumps(
                    {
                        "chunks": [asdict(c) for c in all_chunks],
                        "sources": ingested_sources,
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )

    if not all_chunks:
        print("[ERROR] No chunks were extracted.", file=sys.stderr)
        return 1

    print(
        f"\n[INFO] Embedding {len(all_chunks)} chunks (provider='{args.provider}')...",
        flush=True,
    )
    if args.provider == "fast":
        fast_name, fast_fn = build_fast_hash_embedder(dim=args.dim)
        resolved_model = fast_name
        vectors = fast_fn(all_chunks)
    elif args.provider == "local":
        _, local_fn = build_local_embedder(args.model)
        resolved_model, vectors = local_fn(all_chunks)
    else:
        _, gemini_fn = build_gemini_embedder(
            args.model,
            output_dim=args.dim,
            batch_size=args.batch_size,
            wait_on_429=args.wait_on_429,
        )
        resolved_model, vectors = gemini_fn(all_chunks)

    actual_dim = int(vectors.shape[1])

    index_records: List[Dict[str, Any]] = []
    for chunk, vec in zip(all_chunks, vectors):
        index_records.append(
            {
                "id": chunk.id,
                "source_id": chunk.source_id,
                "section": chunk.section,
                "page": chunk.page,
                "text": chunk.text,
                "embedding": encode_vector_base64(vec, args.dtype),
                "dtype": args.dtype,
            }
        )

    args.index_out.parent.mkdir(parents=True, exist_ok=True)
    args.sources_out.parent.mkdir(parents=True, exist_ok=True)

    index_payload = {
        "version": 1,
        "model": resolved_model,
        "provider": "fast" if resolved_model == "fast-hash-768" else args.provider,
        "dimension": actual_dim,
        "dtype": args.dtype,
        "chunk_count": len(index_records),
        "chunks": index_records,
    }

    args.index_out.write_text(
        json.dumps(index_payload, ensure_ascii=False, separators=(",", ":")),
        encoding="utf-8",
    )
    args.sources_out.write_text(
        json.dumps(ingested_sources, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    index_size_kb = args.index_out.stat().st_size / 1024.0
    sources_size_kb = args.sources_out.stat().st_size / 1024.0
    print("\n=== RAG Index Build Complete ===")
    print(f"Total Chunks Written : {len(index_records)}")
    print(f"Embedding Model Used : {resolved_model}")
    print(f"Embedding Dimension  : {actual_dim} ({args.dtype})")
    print(
        f"Index File Size      : {index_size_kb:.1f} KB ({index_size_kb / 1024.0:.2f} MB) -> {args.index_out}"
    )
    print(f"Sources File Size    : {sources_size_kb:.1f} KB -> {args.sources_out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())