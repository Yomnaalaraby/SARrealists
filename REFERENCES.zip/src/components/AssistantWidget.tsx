import React, { useState } from "react";
import { ClickContext, MapAction } from "../ai/types";
import { ChatPanel } from "../components/ai/ChatPanel";

export interface AssistantWidgetProps {
  /**
   * Pass the ClickContext built when a user clicks a location on your MapLibre map.
   * If undefined, the user can still test using the 3 built-in preset locations.
   */
  clickContext?: ClickContext;
  /**
   * Optional callback triggered when the AI emits a validated Phase 2 navigation action
   * (flyTo, setLayer, setDate, setPersona).
   */
  onExecuteAction?: (action: MapAction) => void;
  /**
   * Whether the drawer starts open on load (defaults to true).
   */
  defaultOpen?: boolean;
}

/**
 * Built-in realistic NISAR sample pixels for the 3 case-study sites so you can
 * test the AI assistant in the browser even when no map pixel has been clicked yet.
 */
export const SAMPLE_SITE_PIXELS: Record<ClickContext["siteId"], ClickContext> = {
  nile_delta: {
    siteId: "nile_delta",
    lon: 31.235,
    lat: 30.812,
    date: "2026-09-14",
    track: 114,
    direction: "DESCENDING",
    values: {
      hh_db: -7.8,
      hv_db: -14.6,
      rvi: 0.56,
      coherence: 0.74,
      los_disp_mm: -12.5,
      disp_rate_mm_yr: -10.8,
      soil_moisture: 0.32,
    },
    polsAvailable: ["HH", "HV"],
    datesCount: 14,
    recordDays: 168,
    siteNotes: {
      why: "Intensive Nile Delta agriculture, irrigation moisture, and sediment compaction.",
      limits: "Seasonal crop growth reduces interferometric coherence; coastal water vapor adds phase noise.",
    },
    activeLayer: "los_disp_mm",
  },
  california: {
    siteId: "california",
    lon: -118.512,
    lat: 34.145,
    date: "2026-09-18",
    track: 42,
    direction: "ASCENDING",
    values: {
      hh_db: -11.4,
      hv_db: -19.9,
      rvi: 0.33,
      coherence: 0.68,
      los_disp_mm: null,
    },
    polsAvailable: ["HH", "HV"],
    datesCount: 12,
    recordDays: 144,
    siteNotes: {
      why: "Los Angeles / California chaparral wildfire burn scar and canopy recovery monitoring.",
      limits: "Steep mountain slopes require gamma-naught terrain correction.",
    },
    activeLayer: "rvi",
  },
  himalaya: {
    siteId: "himalaya",
    lon: 79.082,
    lat: 30.915,
    date: "2026-08-22",
    track: 77,
    direction: "ASCENDING",
    values: {
      hh_db: -9.1,
      hv_db: null,
      rvi: null,
      coherence: 0.21,
      velocity_m_yr: 42.6,
      los_disp_mm: null,
    },
    polsAvailable: ["HH"],
    datesCount: 11,
    recordDays: 132,
    siteNotes: {
      why: "Himalaya Gangotri Glacier ice flow velocity tracked via GOFF pixel offsets.",
      limits: "Fast glacier flow decorrelates 12-day interferometric phase; HH-only acquisition.",
    },
    activeLayer: "velocity_m_yr",
  },
};

export const AssistantWidget: React.FC<AssistantWidgetProps> = ({
  clickContext,
  onExecuteAction,
  defaultOpen = true,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(defaultOpen);
  const [selectedSampleSite, setSelectedSampleSite] =
    useState<ClickContext["siteId"]>("nile_delta");

  // Prefer the real map ClickContext if passed by parent; otherwise use the selected demo pixel
  const activeContext = clickContext ?? SAMPLE_SITE_PIXELS[selectedSampleSite];

  if (!isOpen) {
    return (
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        aria-label="Open NISAR AI Assistant"
        style={{
          position: "fixed",
          bottom: "1.25rem",
          right: "1.25rem",
          zIndex: 9999,
          padding: "0.75rem 1.15rem",
          borderRadius: "9999px",
          border: "1px solid #38bdf8",
          backgroundColor: "#0284c7",
          color: "#ffffff",
          fontWeight: 700,
          fontSize: "0.9rem",
          boxShadow: "0 10px 25px rgba(0, 0, 0, 0.5)",
          cursor: "pointer",
        }}
      >
        Ask NISAR AI Assistant
      </button>
    );
  }

  return (
    <aside
      aria-label="NISAR AI Assistant Drawer"
      style={{
        position: "fixed",
        top: "1rem",
        right: "1rem",
        bottom: "1rem",
        width: "min(430px, calc(100vw - 2rem))",
        zIndex: 9999,
        display: "flex",
        flexDirection: "column",
        boxShadow: "0 20px 40px rgba(0, 0, 0, 0.65)",
        borderRadius: "0.75rem",
      }}
    >
      {/* Top Sample Pixel Selector Bar (shown when parent map hasn't injected a ClickContext yet) */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "0.35rem",
          padding: "0.45rem 0.75rem",
          backgroundColor: "#1e293b",
          borderTopLeftRadius: "0.75rem",
          borderTopRightRadius: "0.75rem",
          border: "1px solid #334155",
          borderBottom: "none",
          fontSize: "0.72rem",
          color: "#cbd5e1",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "0.35rem", flexWrap: "wrap" }}>
          <span style={{ fontWeight: 600, color: "#94a3b8" }}>
            {clickContext ? "Live Map Pixel:" : "Demo Pixel:"}
          </span>
          {(["nile_delta", "california", "himalaya"] as const).map((siteKey) => {
            const isSelected = activeContext.siteId === siteKey;
            return (
              <button
                key={siteKey}
                type="button"
                onClick={() => setSelectedSampleSite(siteKey)}
                style={{
                  padding: "0.2rem 0.5rem",
                  borderRadius: "0.25rem",
                  border: isSelected ? "1px solid #38bdf8" : "1px solid #475569",
                  backgroundColor: isSelected ? "#0369a1" : "#0f172a",
                  color: "#f8fafc",
                  fontSize: "0.7rem",
                  cursor: "pointer",
                }}
              >
                {siteKey === "nile_delta"
                  ? "Nile Delta"
                  : siteKey === "california"
                    ? "California"
                    : "Himalaya"}
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => setIsOpen(false)}
          aria-label="Minimize assistant panel"
          style={{
            padding: "0.15rem 0.45rem",
            borderRadius: "0.25rem",
            border: "1px solid #475569",
            backgroundColor: "#0f172a",
            color: "#94a3b8",
            fontSize: "0.72rem",
            cursor: "pointer",
          }}
        >
          Minimize
        </button>
      </div>

      {/* Main Grounded Chat Panel */}
      <div style={{ flex: 1, minHeight: 0 }}>
        <ChatPanel
          clickContext={activeContext}
          onExecuteAction={(action) => {
            if (action.type === "flyTo") {
              setSelectedSampleSite(action.siteId);
            }
            onExecuteAction?.(action);
          }}
        />
      </div>
    </aside>
  );
};

export default AssistantWidget;