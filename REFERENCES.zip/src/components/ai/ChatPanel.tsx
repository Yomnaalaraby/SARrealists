import React, { useEffect, useRef, useState } from "react";
import { buildFallbackResponse } from "../ai/fallback";
import { loadSavedPersona, savePersona } from "../ai/personas";
import { detectLanguage } from "../ai/promptBuilder";
import {
  ChatRequest,
  ChatResponse,
  CitedSource,
  ClickContext,
  filterValidActions,
  MapAction,
  PersonaId,
  SupportedLanguage,
} from "../ai/types";
import { PersonaSwitcher } from "../../ai/components/PersonaSwitcher";

export interface ChatPanelProps {
  clickContext?: ClickContext;
  defaultLanguage?: SupportedLanguage;
  enableActions?: boolean;
  onExecuteAction?: (action: MapAction) => void;
}

interface ChatMessageItem {
  id: string;
  role: "user" | "assistant";
  text: string;
  persona?: PersonaId;
  language: SupportedLanguage;
  sources?: CitedSource[];
  confidenceTag?: string;
  actions?: MapAction[];
  isFallback?: boolean;
}

/**
 * Grounded NISAR Chat Assistant Panel with:
 * - PersonaSwitcher persisted in localStorage
 * - "Explain this pixel" one-click contextual analysis button
 * - Real-time SSE streaming display with client-side fallback guarantee
 * - Clickable [S1], [S2] citation chips linking to official NASA/JPL/ASF sources
 * - Automatic RTL layout for Arabic questions and responses
 */
export const ChatPanel: React.FC<ChatPanelProps> = ({
  clickContext,
  defaultLanguage = "en",
  enableActions = true,
  onExecuteAction,
}) => {
  const [persona, setPersona] = useState<PersonaId>(() => loadSavedPersona());
  const [uiLanguage, setUiLanguage] =
    useState<SupportedLanguage>(defaultLanguage);
  const [questionInput, setQuestionInput] = useState<string>("");
  const [messages, setMessages] = useState<ChatMessageItem[]>([]);
  const [streamingText, setStreamingText] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingText]);

  const handleActionExecution = (actions: MapAction[]) => {
    const valid = filterValidActions(actions);
    for (const act of valid) {
      if (act.type === "setPersona") {
        setPersona(act.persona);
        savePersona(act.persona);
      }
      onExecuteAction?.(act);
    }
  };

  const sendChatRequest = async (promptText: string) => {
    const trimmed = promptText.trim();
    if (!trimmed || isLoading) {
      return;
    }

    const detectedLang = detectLanguage(trimmed, undefined);
    setUiLanguage(detectedLang);
    setErrorBanner(null);

    const userMsg: ChatMessageItem = {
      id: `user-${Date.now()}`,
      role: "user",
      text: trimmed,
      language: detectedLang,
    };

    setMessages((prev) => [...prev, userMsg]);
    setQuestionInput("");
    setIsLoading(true);
    setStreamingText("");

    const payload: ChatRequest = {
      question: trimmed,
      persona,
      clickContext,
      language: detectedLang,
      enableActions,
    };

    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const response = await fetch("/api/chat?stream=1", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "text/event-stream",
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      if (!response.ok || !response.body) {
        throw new Error(`HTTP ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";
      let liveAccumulated = "";
      let metaSources: CitedSource[] = [];
      let metaConfidence = "";
      let finalPayload: ChatResponse | null = null;

      while (true) {
        const { value, done } = await reader.read();
        if (done) {
          break;
        }
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split("\n\n");
        buffer = events.pop() ?? "";

        for (const rawEvent of events) {
          const lines = rawEvent.split("\n");
          let eventType = "message";
          let dataStr = "";

          for (const line of lines) {
            if (line.startsWith("event:")) {
              eventType = line.slice(6).trim();
            } else if (line.startsWith("data:")) {
              dataStr += line.slice(5).trim();
            }
          }

          if (!dataStr) {
            continue;
          }

          try {
            const parsed = JSON.parse(dataStr) as Record<string, unknown>;
            if (eventType === "meta") {
              metaSources = (parsed.sources as CitedSource[]) ?? [];
              metaConfidence = (parsed.confidenceTag as string) ?? "";
            } else if (eventType === "delta") {
              const deltaText = (parsed.text as string) ?? "";
              liveAccumulated += deltaText;
              setStreamingText(liveAccumulated);
            } else if (eventType === "actions") {
              const rawActions = parsed.actions;
              const valid = filterValidActions(rawActions);
              if (valid.length > 0) {
                handleActionExecution(valid);
              }
            } else if (eventType === "done") {
              finalPayload = parsed as unknown as ChatResponse;
            }
          } catch {
            // Ignore malformed SSE frame
          }
        }
      }

      const resolved: ChatResponse =
        finalPayload ??
        ({
          answer: liveAccumulated,
          persona,
          language: detectedLang,
          sources: metaSources,
          confidenceTag: metaConfidence,
        } satisfies ChatResponse);

      if (resolved.actions && resolved.actions.length > 0) {
        handleActionExecution(resolved.actions);
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          text: resolved.answer,
          persona: resolved.persona,
          language: resolved.language,
          sources: resolved.sources,
          confidenceTag: resolved.confidenceTag,
          actions: resolved.actions,
          isFallback: resolved.isFallback,
        },
      ]);
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") {
        return;
      }
      // Client-side deterministic fallback so the live demo never breaks
      const fallback = buildFallbackResponse(payload, []);
      setErrorBanner(
        detectedLang === "ar"
          ? "تعذر الاتصال بالخادم؛ تم توليد الشرح من بيانات النقطة مباشرة."
          : "API unreachable or rate-limited; showing deterministic explanation from pixel context."
      );
      setMessages((prev) => [
        ...prev,
        {
          id: `assistant-fallback-${Date.now()}`,
          role: "assistant",
          text: fallback.answer,
          persona: fallback.persona,
          language: fallback.language,
          sources: fallback.sources,
          confidenceTag: fallback.confidenceTag,
          isFallback: true,
        },
      ]);
    } finally {
      setStreamingText("");
      setIsLoading(false);
    }
  };

  const handleExplainPixel = () => {
    if (!clickContext || isLoading) {
      return;
    }
    const defaultPrompt =
      uiLanguage === "ar"
        ? `اشرح قراءات الرادار في هذه النقطة (${clickContext.lat.toFixed(4)}, ${clickContext.lon.toFixed(4)}) في موقع ${clickContext.siteId} بتاريخ ${clickContext.date}.`
        : `Explain this pixel at (${clickContext.lat.toFixed(4)}, ${clickContext.lon.toFixed(4)}) in ${clickContext.siteId} on ${clickContext.date}.`;
    void sendChatRequest(defaultPrompt);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void sendChatRequest(questionInput);
    }
  };

  const isRtl = uiLanguage === "ar";

  return (
    <section
      aria-label={
        isRtl ? "مساعد رادار NISAR الذكي" : "NISAR Grounded Radar Assistant"
      }
      dir={isRtl ? "rtl" : "ltr"}
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        maxHeight: "100vh",
        backgroundColor: "#090d16",
        color: "#f8fafc",
        border: "1px solid #1e293b",
        borderRadius: "0.75rem",
        overflow: "hidden",
        fontFamily: "system-ui, -apple-system, sans-serif",
      }}
    >
      {/* Top Header & Language Toggle */}
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "0.75rem 1rem",
          borderBottom: "1px solid #1e293b",
          backgroundColor: "#0f172a",
        }}
      >
        <div>
          <h2 style={{ margin: 0, fontSize: "1rem", fontWeight: 700 }}>
            {isRtl
              ? "مساعد NISAR الموثق (Dancing with the SARs)"
              : "NISAR Grounded Assistant"}
          </h2>
          <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>
            {clickContext
              ? `${clickContext.siteId} | (${clickContext.lat.toFixed(3)}, ${clickContext.lon.toFixed(3)}) | ${clickContext.date}`
              : isRtl
                ? "انقر على الخريطة لتحديد نقطة"
                : "Click a map location to inject pixel data"}
          </span>
        </div>

        <button
          type="button"
          onClick={() => setUiLanguage((prev) => (prev === "en" ? "ar" : "en"))}
          aria-label="Toggle language between English and Arabic"
          style={{
            padding: "0.35rem 0.65rem",
            borderRadius: "0.375rem",
            border: "1px solid #334155",
            backgroundColor: "#1e293b",
            color: "#e2e8f0",
            fontSize: "0.75rem",
            cursor: "pointer",
          }}
        >
          {uiLanguage === "en" ? "العربية (AR)" : "English (EN)"}
        </button>
      </header>

      {/* Persona Switcher + Explain This Pixel Bar */}
      <div
        style={{
          padding: "0.75rem",
          borderBottom: "1px solid #1e293b",
          display: "flex",
          flexDirection: "column",
          gap: "0.625rem",
        }}
      >
        <PersonaSwitcher
          value={persona}
          onChange={setPersona}
          language={uiLanguage}
          disabled={isLoading}
        />

        <button
          type="button"
          onClick={handleExplainPixel}
          disabled={!clickContext || isLoading}
          style={{
            width: "100%",
            padding: "0.6rem 0.85rem",
            borderRadius: "0.5rem",
            border: "none",
            backgroundColor:
              !clickContext || isLoading ? "#1e293b" : "#0ea5e9",
            color: !clickContext || isLoading ? "#64748b" : "#082f49",
            fontWeight: 700,
            fontSize: "0.875rem",
            cursor:
              !clickContext || isLoading ? "not-allowed" : "pointer",
          }}
        >
          {clickContext
            ? isRtl
              ? `اشرح هذه النقطة (${clickContext.siteId} - ${clickContext.date})`
              : `Explain this pixel (${clickContext.siteId} • ${clickContext.date})`
            : isRtl
              ? "اشرح هذه النقطة (حدد موقعاً على الخريطة أولاً)"
              : "Explain this pixel (click a map point first)"}
        </button>
      </div>

      {/* Error / Offline Fallback Banner */}
      {errorBanner && (
        <div
          role="status"
          style={{
            padding: "0.5rem 0.85rem",
            backgroundColor: "#422006",
            borderBottom: "1px solid #854d0e",
            color: "#fef08a",
            fontSize: "0.75rem",
          }}
        >
          {errorBanner}
        </div>
      )}

      {/* Conversation History */}
      <div
        role="log"
        aria-live="polite"
        style={{
          flex: 1,
          overflowY: "auto",
          padding: "0.85rem",
          display: "flex",
          flexDirection: "column",
          gap: "0.85rem",
        }}
      >
        {messages.length === 0 && !streamingText && (
          <div
            style={{
              padding: "1rem",
              borderRadius: "0.5rem",
              backgroundColor: "#0f172a",
              border: "1px dashed #334155",
              color: "#94a3b8",
              fontSize: "0.85rem",
              lineHeight: 1.5,
            }}
          >
            {isRtl
              ? "اسأل أي سؤال حول مهمة NISAR أو فيزياء الرادار (L-band / S-band) أو اضغط على 'اشرح هذه النقطة' لتحليل القيم الحقيقية للنقطة المحددة."
              : "Ask a question about the NASA-ISRO NISAR mission, radar physics, or click 'Explain this pixel' to analyze the injected map values."}
          </div>
        )}

        {messages.map((msg) => {
          const msgRtl = msg.language === "ar";
          return (
            <article
              key={msg.id}
              dir={msgRtl ? "rtl" : "ltr"}
              style={{
                alignSelf: msg.role === "user" ? "flex-end" : "stretch",
                maxWidth: msg.role === "user" ? "85%" : "100%",
                padding: "0.75rem 0.9rem",
                borderRadius: "0.625rem",
                backgroundColor:
                  msg.role === "user" ? "#0369a1" : "#111827",
                border:
                  msg.role === "user"
                    ? "1px solid #0284c7"
                    : "1px solid #1f2937",
                fontSize: "0.875rem",
                lineHeight: 1.55,
                whiteSpace: "pre-wrap",
              }}
            >
              {msg.text}

              {/* Citation Chips linking to official NASA/ASF source URLs */}
              {msg.role === "assistant" &&
                msg.sources &&
                msg.sources.length > 0 && (
                  <div
                    style={{
                      marginTop: "0.65rem",
                      paddingTop: "0.5rem",
                      borderTop: "1px solid #1e293b",
                      display: "flex",
                      flexWrap: "wrap",
                      gap: "0.375rem",
                    }}
                  >
                    {msg.sources.map((src) => {
                      const isExternal = src.url.startsWith("http");
                      return (
                        <a
                          key={`${msg.id}-${src.citationTag}`}
                          href={isExternal ? src.url : `#${src.id}`}
                          target={isExternal ? "_blank" : undefined}
                          rel={
                            isExternal ? "noopener noreferrer" : undefined
                          }
                          title={`${src.title} (${src.attribution})`}
                          style={{
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "0.25rem",
                            padding: "0.2rem 0.5rem",
                            borderRadius: "9999px",
                            backgroundColor: "#1e293b",
                            border: "1px solid #38bdf8",
                            color: "#7dd3fc",
                            fontSize: "0.72rem",
                            textDecoration: "none",
                            fontWeight: 600,
                          }}
                        >
                          <span>[{src.citationTag}]</span>
                          <span
                            style={{
                              maxWidth: "180px",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                              whiteSpace: "nowrap",
                            }}
                          >
                            {src.title}
                          </span>
                        </a>
                      );
                    })}
                  </div>
                )}
            </article>
          );
        })}

        {/* Active Streaming Bubble */}
        {isLoading && (
          <article
            aria-busy="true"
            style={{
              padding: "0.75rem 0.9rem",
              borderRadius: "0.625rem",
              backgroundColor: "#111827",
              border: "1px solid #38bdf8",
              fontSize: "0.875rem",
              lineHeight: 1.55,
              whiteSpace: "pre-wrap",
            }}
          >
            {streamingText ||
              (isRtl
                ? "جارٍ البحث في مصادر NISAR الرسمية..."
                : "Retrieving official NISAR sources & analyzing pixel...")}
          </article>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Question Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void sendChatRequest(questionInput);
        }}
        style={{
          padding: "0.75rem",
          borderTop: "1px solid #1e293b",
          backgroundColor: "#0f172a",
          display: "flex",
          gap: "0.5rem",
          alignItems: "flex-end",
        }}
      >
        <textarea
          rows={2}
          value={questionInput}
          onChange={(e) => setQuestionInput(e.target.value)}
          onKeyDown={handleKeyDown}
          maxLength={1200}
          disabled={isLoading}
          placeholder={
            isRtl
              ? "اكتب سؤالك بالعربية أو الإنجليزية... (Enter للإرسال)"
              : "Ask about this pixel or NISAR radar physics... (Enter to send)"
          }
          aria-label={isRtl ? "سؤالك" : "Your question"}
          style={{
            flex: 1,
            resize: "none",
            padding: "0.5rem 0.65rem",
            borderRadius: "0.5rem",
            border: "1px solid #334155",
            backgroundColor: "#090d16",
            color: "#f8fafc",
            fontSize: "0.85rem",
            fontFamily: "inherit",
          }}
        />
        <button
          type="submit"
          disabled={isLoading || questionInput.trim().length === 0}
          style={{
            padding: "0.6rem 1rem",
            borderRadius: "0.5rem",
            border: "none",
            backgroundColor:
              isLoading || questionInput.trim().length === 0
                ? "#1e293b"
                : "#38bdf8",
            color:
              isLoading || questionInput.trim().length === 0
                ? "#64748b"
                : "#082f49",
            fontWeight: 700,
            fontSize: "0.85rem",
            cursor:
              isLoading || questionInput.trim().length === 0
                ? "not-allowed"
                : "pointer",
          }}
        >
          {isRtl ? "إرسال" : "Send"}
        </button>
      </form>
    </section>
  );
};

export default ChatPanel;