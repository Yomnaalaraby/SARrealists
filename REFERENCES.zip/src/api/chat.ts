import crypto from "node:crypto";
import type { IncomingMessage, ServerResponse } from "node:http";
import { retrieveTopChunks } from "../server/retrieval";
import { buildFallbackResponse } from "../src/ai/fallback";
import { buildPrompts } from "../src/ai/promptBuilder";
import {
  GeminiProvider,
  LLMProvider,
  postProcessModelOutput,
} from "../src/ai/provider";
import { ChatRequestSchema, ChatResponse } from "../src/ai/types";

/**
 * Per-IP sliding-window rate limiter state (persists across warm serverless invocations).
 */
interface RateBucket {
  count: number;
  resetAt: number;
}

const RATE_LIMIT_WINDOW_MS = Number(
  process.env.CHAT_RATE_WINDOW_MS ?? "60000"
);
const RATE_LIMIT_MAX_REQUESTS = Number(
  process.env.CHAT_RATE_MAX_REQUESTS ?? "20"
);
const rateBuckets = new Map<string, RateBucket>();

/**
 * In-memory response cache for identical (persona, question, clickContext) requests
 * to control API token costs during live judging demos.
 */
interface CacheEntry {
  response: ChatResponse;
  expiresAt: number;
}

const CACHE_TTL_MS = Number(process.env.CHAT_CACHE_TTL_MS ?? "300000"); // 5 minutes
const CACHE_MAX_ENTRIES = 200;
const responseCache = new Map<string, CacheEntry>();

let sharedProvider: LLMProvider | null = null;

function getProvider(): LLMProvider {
  if (!sharedProvider) {
    sharedProvider = new GeminiProvider();
  }
  return sharedProvider;
}

/**
 * Allows unit tests to inject a mock LLMProvider.
 */
export function setServerProviderForTesting(provider: LLMProvider | null): void {
  sharedProvider = provider;
}

/**
 * Clears rate-limit and response caches (used in unit tests).
 */
export function resetServerStateForTesting(): void {
  rateBuckets.clear();
  responseCache.clear();
}

function getClientIp(req: IncomingMessage): string {
  const xff = req.headers["x-forwarded-for"];
  if (typeof xff === "string" && xff.length > 0) {
    return xff.split(",")[0].trim();
  }
  return req.socket?.remoteAddress ?? "127.0.0.1";
}

function checkRateLimit(ip: string): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  if (rateBuckets.size > 2000) {
    for (const [key, b] of rateBuckets.entries()) {
      if (b.resetAt <= now) {
        rateBuckets.delete(key);
      }
    }
  }

  const bucket = rateBuckets.get(ip);
  if (!bucket || bucket.resetAt <= now) {
    rateBuckets.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return { allowed: true, retryAfterSec: 0 };
  }

  if (bucket.count >= RATE_LIMIT_MAX_REQUESTS) {
    const retryAfterSec = Math.max(1, Math.ceil((bucket.resetAt - now) / 1000));
    return { allowed: false, retryAfterSec };
  }

  bucket.count += 1;
  return { allowed: true, retryAfterSec: 0 };
}

function computeCacheKey(payload: unknown): string {
  return crypto
    .createHash("sha256")
    .update(JSON.stringify(payload))
    .digest("hex");
}

async function readRequestBody(
  req: IncomingMessage & { body?: unknown },
  maxBytes = 32_768
): Promise<unknown> {
  if (req.body !== undefined && req.body !== null) {
    if (typeof req.body === "string") {
      return JSON.parse(req.body);
    }
    return req.body;
  }

  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let totalBytes = 0;

    req.on("data", (chunk: Buffer | string) => {
      const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      totalBytes += buf.byteLength;
      if (totalBytes > maxBytes) {
        reject(new Error("PAYLOAD_TOO_LARGE"));
        req.destroy();
        return;
      }
      chunks.push(buf);
    });

    req.on("end", () => {
      try {
        const raw = Buffer.concat(chunks).toString("utf-8");
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error("INVALID_JSON"));
      }
    });

    req.on("error", (err) => reject(err));
  });
}

function sendJson(
  res: ServerResponse,
  statusCode: number,
  body: Record<string, unknown>
): void {
  res.statusCode = statusCode;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(body));
}

function writeSseEvent(
  res: ServerResponse,
  event: string,
  data: unknown
): void {
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

/**
 * Vercel Serverless Handler for POST /api/chat
 */
export default async function handler(
  req: IncomingMessage & { body?: unknown; query?: Record<string, string> },
  res: ServerResponse
): Promise<void> {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    sendJson(res, 405, { error: "Method Not Allowed. Use POST." });
    return;
  }

  // 1. Per-IP Rate Limit Check
  const clientIp = getClientIp(req);
  const rateStatus = checkRateLimit(clientIp);
  if (!rateStatus.allowed) {
    res.setHeader("Retry-After", String(rateStatus.retryAfterSec));
    sendJson(res, 429, {
      error: `Rate limit exceeded. Please wait ${rateStatus.retryAfterSec}s.`,
    });
    return;
  }

  // 2. Parse & Validate Input with Zod (rejects malformed ClickContext or oversized inputs)
  let rawBody: unknown;
  try {
    rawBody = await readRequestBody(req);
  } catch (err) {
    const code =
      err instanceof Error && err.message === "PAYLOAD_TOO_LARGE" ? 413 : 400;
    sendJson(res, code, {
      error:
        code === 413
          ? "Request body exceeds maximum size limit (32 KB)."
          : "Malformed JSON request body.",
    });
    return;
  }

  const parsed = ChatRequestSchema.safeParse(rawBody);
  if (!parsed.success) {
    sendJson(res, 400, {
      error: "Invalid request payload.",
      details: parsed.error.issues.map((i) => ({
        path: i.path.join("."),
        message: i.message,
      })),
    });
    return;
  }

  const chatReq = parsed.data;
  const wantsStream =
    (req.headers.accept ?? "").includes("text/event-stream") ||
    (req.url ?? "").includes("stream=1");

  // 3. Check Identical Request Cache (Cost Control)
  const cacheKey = computeCacheKey(chatReq);
  const cached = responseCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    if (wantsStream) {
      res.statusCode = 200;
      res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
      res.setHeader("Cache-Control", "no-cache, no-transform");
      res.setHeader("Connection", "keep-alive");
      writeSseEvent(res, "meta", {
        persona: cached.response.persona,
        language: cached.response.language,
        sources: cached.response.sources,
        confidenceTag: cached.response.confidenceTag,
        cached: true,
      });
      writeSseEvent(res, "delta", { text: cached.response.answer });
      if (cached.response.actions && cached.response.actions.length > 0) {
        writeSseEvent(res, "actions", { actions: cached.response.actions });
      }
      writeSseEvent(res, "done", cached.response);
      res.end();
      return;
    }
    sendJson(res, 200, cached.response as unknown as Record<string, unknown>);
    return;
  }

  // 4. Runtime RAG Retrieval (Cosine top-k = 5 with similarity floor & section deduplication)
  const provider = getProvider();
  const topK = Number(process.env.RAG_TOP_K ?? "5");
  const minScore = Number(process.env.RAG_SIMILARITY_FLOOR ?? "0.28");

  const queryEmbedding = await provider.embedQuery(
    `${chatReq.question} ${chatReq.clickContext?.siteId ?? ""} ${chatReq.clickContext?.activeLayer ?? ""}`
  );

  const retrieval = retrieveTopChunks({
    question: chatReq.question,
    clickContext: chatReq.clickContext,
    queryEmbedding: queryEmbedding ?? undefined,
    topK: Number.isFinite(topK) ? topK : 5,
    minScore: Number.isFinite(minScore) ? minScore : 0.28,
  });

  // 5. Build Grounded System Prompt & User Turn
  const built = buildPrompts({
    personaId: chatReq.persona,
    question: chatReq.question,
    clickContext: chatReq.clickContext,
    retrievedChunks: retrieval.chunks,
    language: chatReq.language,
    enableActions: chatReq.enableActions ?? true,
  });

  // 6. Execute Provider Generation (Streaming or JSON) with Deterministic Fallback on Failure
  if (wantsStream) {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");

    writeSseEvent(res, "meta", {
      persona: chatReq.persona,
      language: built.language,
      sources: retrieval.citedSources,
      confidenceTag: built.confidenceTag,
    });

    try {
      let accumulated = "";
      for await (const chunk of provider.streamText({
        systemPrompt: built.systemPrompt,
        userTurn: built.userTurn,
      })) {
        accumulated += chunk;
        writeSseEvent(res, "delta", { text: chunk });
      }

      const processed = postProcessModelOutput(
        accumulated,
        built.confidenceTag,
        built.maxWords,
        true
      );

      const finalResponse: ChatResponse = {
        answer: processed.cleanAnswer,
        persona: chatReq.persona,
        language: built.language,
        sources: retrieval.citedSources,
        confidenceTag: built.confidenceTag,
        actions: processed.actions.length > 0 ? processed.actions : undefined,
        isFallback: false,
      };

      if (processed.actions.length > 0) {
        writeSseEvent(res, "actions", { actions: processed.actions });
      }
      writeSseEvent(res, "done", finalResponse);

      if (responseCache.size >= CACHE_MAX_ENTRIES) {
        const oldestKey = responseCache.keys().next().value;
        if (oldestKey) {
          responseCache.delete(oldestKey);
        }
      }
      responseCache.set(cacheKey, {
        response: finalResponse,
        expiresAt: Date.now() + CACHE_TTL_MS,
      });
      res.end();
      return;
    } catch {
      const fallback = buildFallbackResponse(chatReq, retrieval.citedSources);
      writeSseEvent(res, "delta", { text: fallback.answer });
      writeSseEvent(res, "done", fallback);
      res.end();
      return;
    }
  }

  // Non-streaming JSON mode
  try {
    const rawModelText = await provider.generateText({
      systemPrompt: built.systemPrompt,
      userTurn: built.userTurn,
    });

    const processed = postProcessModelOutput(
      rawModelText,
      built.confidenceTag,
      built.maxWords,
      true
    );

    const finalResponse: ChatResponse = {
      answer: processed.cleanAnswer,
      persona: chatReq.persona,
      language: built.language,
      sources: retrieval.citedSources,
      confidenceTag: built.confidenceTag,
      actions: processed.actions.length > 0 ? processed.actions : undefined,
      isFallback: false,
    };

    if (responseCache.size >= CACHE_MAX_ENTRIES) {
      const oldestKey = responseCache.keys().next().value;
      if (oldestKey) {
        responseCache.delete(oldestKey);
      }
    }
    responseCache.set(cacheKey, {
      response: finalResponse,
      expiresAt: Date.now() + CACHE_TTL_MS,
    });

    sendJson(res, 200, finalResponse as unknown as Record<string, unknown>);
  } catch {
    const fallback = buildFallbackResponse(chatReq, retrieval.citedSources);
    sendJson(res, 200, fallback as unknown as Record<string, unknown>);
  }
}