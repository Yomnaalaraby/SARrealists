import { filterValidActions, MapAction } from "./types";

export interface ProviderConfig {
  apiKey: string;
  generationModel: string;
  embeddingModel: string;
  embeddingDimension: number;
  maxOutputTokens: number;
  temperature: number;
  timeoutMs: number;
}

export interface GenerateInput {
  systemPrompt: string;
  userTurn: string;
  maxOutputTokens?: number;
  temperature?: number;
}

export interface LLMProvider {
  readonly modelName: string;
  embedQuery(text: string): Promise<Float32Array | null>;
  generateText(input: GenerateInput): Promise<string>;
  streamText(input: GenerateInput): AsyncGenerator<string, void, unknown>;
}

export function getProviderConfigFromEnv(): ProviderConfig {
  const apiKey = (process.env.GEMINI_API_KEY ?? "").trim();
  const generationModel = (
    process.env.GEMINI_MODEL ?? "gemini-2.5-flash"
  ).trim();
  const embeddingModel = (
    process.env.GEMINI_EMBEDDING_MODEL ?? "gemini-embedding-001"
  ).trim();
  const embeddingDimension = Number(
    process.env.GEMINI_EMBEDDING_DIM ?? "768"
  );
  const maxOutputTokens = Number(
    process.env.GEMINI_MAX_OUTPUT_TOKENS ?? "450"
  );
  const temperature = Number(process.env.GEMINI_TEMPERATURE ?? "0.1");
  const timeoutMs = Number(process.env.GEMINI_TIMEOUT_MS ?? "18000");

  return {
    apiKey,
    generationModel,
    embeddingModel,
    embeddingDimension: Number.isFinite(embeddingDimension)
      ? embeddingDimension
      : 768,
    maxOutputTokens: Number.isFinite(maxOutputTokens) ? maxOutputTokens : 450,
    temperature: Number.isFinite(temperature) ? temperature : 0.1,
    timeoutMs: Number.isFinite(timeoutMs) ? timeoutMs : 18000,
  };
}

interface GeminiGenerateResponse {
  candidates?: Array<{
    content?: {
      parts?: Array<{
        text?: string;
      }>;
    };
  }>;
}

interface GeminiEmbeddingResponse {
  embedding?: {
    values?: number[];
  };
}

interface GeminiModelsListResponse {
  models?: Array<{
    name?: string;
    supportedGenerationMethods?: string[];
  }>;
}

let cachedWorkingGenerationModel: string | null = null;

export class GeminiProvider implements LLMProvider {
  private readonly config: ProviderConfig;

  constructor(config?: Partial<ProviderConfig>) {
    const envCfg = getProviderConfigFromEnv();
    this.config = { ...envCfg, ...config };
  }

  public get modelName(): string {
    return cachedWorkingGenerationModel ?? this.config.generationModel;
  }

  private assertApiKey(): void {
    if (!this.config.apiKey) {
      throw new Error("GEMINI_API_KEY is not configured on the server.");
    }
  }

  /**
   * Queries GET /v1beta/models to find an active model supporting `generateContent`
   * if the configured default model returns HTTP 404.
   */
  private async discoverGenerationModel(): Promise<string> {
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models",
      {
        method: "GET",
        headers: {
          "x-goog-api-key": this.config.apiKey,
        },
      }
    );

    if (!response.ok) {
      throw new Error(`ListModels HTTP ${response.status}`);
    }

    const data = (await response.json()) as GeminiModelsListResponse;
    const candidates: string[] = [];

    for (const m of data.models ?? []) {
      const methods = m.supportedGenerationMethods ?? [];
      if (m.name && methods.includes("generateContent")) {
        candidates.push(m.name);
      }
    }

    const preferred = [
      "models/gemini-3.6-flash",
      "models/gemini-2.5-flash",
      "models/gemini-2.0-flash",
      "models/gemini-1.5-flash",
    ];

    for (const pref of preferred) {
      if (candidates.includes(pref)) {
        cachedWorkingGenerationModel = pref;
        return pref;
      }
    }

    const anyFlash = candidates.find((c) => c.includes("flash"));
    if (anyFlash) {
      cachedWorkingGenerationModel = anyFlash;
      return anyFlash;
    }

    if (candidates.length > 0) {
      cachedWorkingGenerationModel = candidates[0];
      return candidates[0];
    }

    throw new Error("No generateContent models available for this API key.");
  }

  public async embedQuery(text: string): Promise<Float32Array | null> {
    if (!this.config.apiKey) {
      return null;
    }

    const modelPath = this.config.embeddingModel.startsWith("models/")
      ? this.config.embeddingModel
      : `models/${this.config.embeddingModel}`;
    const url = `https://generativelanguage.googleapis.com/v1beta/${modelPath}:embedContent`;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": this.config.apiKey,
        },
        body: JSON.stringify({
          model: modelPath,
          content: {
            parts: [{ text: text.slice(0, 2000) }],
          },
          outputDimensionality: this.config.embeddingDimension,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        return null;
      }

      const data = (await response.json()) as GeminiEmbeddingResponse;
      const values = data.embedding?.values;
      if (!Array.isArray(values) || values.length === 0) {
        return null;
      }

      const vec = new Float32Array(values.length);
      let normSq = 0;
      for (let i = 0; i < values.length; i++) {
        const val = Number(values[i]) || 0;
        vec[i] = val;
        normSq += val * val;
      }
      const norm = Math.sqrt(normSq);
      if (norm > 0) {
        for (let i = 0; i < vec.length; i++) {
          vec[i] /= norm;
        }
      }
      return vec;
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  public async generateText(input: GenerateInput): Promise<string> {
    this.assertApiKey();

    const rawModel =
      cachedWorkingGenerationModel ?? this.config.generationModel;
    let modelPath = rawModel.startsWith("models/")
      ? rawModel
      : `models/${rawModel}`;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.config.timeoutMs);

    const callModel = async (targetModel: string): Promise<Response> => {
      const url = `https://generativelanguage.googleapis.com/v1beta/${targetModel}:generateContent`;
      return fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": this.config.apiKey,
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: input.systemPrompt }],
          },
          contents: [
            {
              role: "user",
              parts: [{ text: input.userTurn }],
            },
          ],
          generationConfig: {
            temperature: input.temperature ?? this.config.temperature,
            maxOutputTokens:
              input.maxOutputTokens ?? this.config.maxOutputTokens,
          },
        }),
        signal: controller.signal,
      });
    };

    try {
      let response = await callModel(modelPath);
      if (response.status === 404) {
        modelPath = await this.discoverGenerationModel();
        response = await callModel(modelPath);
      }

      if (!response.ok) {
        throw new Error(`Gemini API HTTP ${response.status}`);
      }

      const payload = (await response.json()) as GeminiGenerateResponse;
      const parts = payload.candidates?.[0]?.content?.parts ?? [];
      const text = parts
        .map((p) => p.text ?? "")
        .join("")
        .trim();

      if (!text) {
        throw new Error("Gemini API returned an empty candidate.");
      }

      return text;
    } finally {
      clearTimeout(timer);
    }
  }

  public async *streamText(
    input: GenerateInput
  ): AsyncGenerator<string, void, unknown> {
    this.assertApiKey();

    const rawModel =
      cachedWorkingGenerationModel ?? this.config.generationModel;
    let modelPath = rawModel.startsWith("models/")
      ? rawModel
      : `models/${rawModel}`;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.config.timeoutMs);

    const openStream = async (targetModel: string): Promise<Response> => {
      const url = `https://generativelanguage.googleapis.com/v1beta/${targetModel}:streamGenerateContent?alt=sse`;
      return fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": this.config.apiKey,
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: input.systemPrompt }],
          },
          contents: [
            {
              role: "user",
              parts: [{ text: input.userTurn }],
            },
          ],
          generationConfig: {
            temperature: input.temperature ?? this.config.temperature,
            maxOutputTokens:
              input.maxOutputTokens ?? this.config.maxOutputTokens,
          },
        }),
        signal: controller.signal,
      });
    };

    try {
      let response = await openStream(modelPath);
      if (response.status === 404) {
        modelPath = await this.discoverGenerationModel();
        response = await openStream(modelPath);
      }

      if (!response.ok || !response.body) {
        throw new Error(`Gemini stream HTTP ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) {
          break;
        }
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split(/\r?\n/);
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) {
            continue;
          }
          const jsonStr = trimmed.slice(5).trim();
          if (!jsonStr || jsonStr === "[DONE]") {
            continue;
          }
          try {
            const parsed = JSON.parse(jsonStr) as GeminiGenerateResponse;
            const parts = parsed.candidates?.[0]?.content?.parts ?? [];
            for (const part of parts) {
              if (part.text) {
                yield part.text;
              }
            }
          } catch {
            // Ignore partial JSON frame
          }
        }
      }
    } finally {
      clearTimeout(timer);
    }
  }
}

export interface PostProcessedModelOutput {
  cleanAnswer: string;
  actions: MapAction[];
}

export function postProcessModelOutput(
  rawText: string,
  confidenceTag: string,
  maxWords: number,
  forbidEmojis = true
): PostProcessedModelOutput {
  let working = rawText.trim();
  let actions: MapAction[] = [];

  const actionFenceRegex = /```json_actions\s*([\s\S]*?)```/i;
  const match = working.match(actionFenceRegex);
  if (match && match[1]) {
    try {
      const rawJson: unknown = JSON.parse(match[1].trim());
      actions = filterValidActions(rawJson);
    } catch {
      actions = [];
    }
    working = working.replace(actionFenceRegex, "").trim();
  }

  if (forbidEmojis) {
    working = working.replace(
      /[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu,
      ""
    );
  }

  const confidenceLineRegex =
    /(?:^|\n)(?:Confidence & data limits:|الثقة وحدود البيانات \(Confidence & data limits\):)[^\n]*$/i;
  const bodyOnly = working.replace(confidenceLineRegex, "").trim();

  const words = bodyOnly.split(/\s+/).filter(Boolean);
  const clampedBody =
    words.length > maxWords
      ? `${words.slice(0, maxWords).join(" ")}...`
      : bodyOnly;

  const cleanAnswer = `${clampedBody}\n\n${confidenceTag}`;
  return {
    cleanAnswer,
    actions,
  };
}