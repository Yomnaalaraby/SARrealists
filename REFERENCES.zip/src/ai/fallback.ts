import { PERSONAS } from "./personas";
import {
  buildConfidenceTag,
  detectLanguage,
  sanitizeUntrustedText,
} from "./promptBuilder";
import {
  ChatRequest,
  ChatResponse,
  CitedSource,
  ClickContext,
  SupportedLanguage,
} from "./types";

const SITE_LABELS_EN: Record<ClickContext["siteId"], string> = {
  california: "California Wildfires & Vegetation Corridor",
  nile_delta: "Nile Delta Agriculture, Subsidence & Coastline",
  himalaya: "Himalaya Gangotri Glacier System",
};

const SITE_LABELS_AR: Record<ClickContext["siteId"], string> = {
  california: "حرائق الغابات والغطاء النباتي في كاليفورنيا (California)",
  nile_delta: "دلتا النيل - الزراعة وهبوط الأرض والساحل (Nile Delta)",
  himalaya: "نهر غانغوتري الجليدي في الهيمالايا (Himalaya Gangotri)",
};

const INJECTION_PATTERN =
  /<\s*\/?\s*(?:system|instruction|click_context_data|user_question)|ignore\s+all\s+previous|override\s*:/i;

/**
 * Drops or sanitizes untrusted siteNotes if they contain a prompt-injection payload.
 */
function safeSiteNote(note: string | undefined): string {
  if (!note) {
    return "";
  }
  if (INJECTION_PATTERN.test(note)) {
    return "";
  }
  return ` ${sanitizeUntrustedText(note, 300)}`;
}

/**
 * Formats available numeric metrics and explicitly lists unavailable (null) metrics
 * without inventing or rounding any numbers beyond what is in ClickContext.
 */
function summarizeValues(
  ctx: ClickContext,
  lang: SupportedLanguage
): {
  availableText: string;
  unavailableText: string;
} {
  const available: string[] = [];
  const unavailable: string[] = [];

  for (const [key, val] of Object.entries(ctx.values)) {
    if (val === null || val === undefined || !Number.isFinite(val)) {
      unavailable.push(key);
    } else {
      available.push(`${key} = ${val}`);
    }
  }

  if (lang === "ar") {
    return {
      availableText:
        available.length > 0
          ? available.join("، ")
          : "لا توجد قيم رقمية مسجلة (none)",
      unavailableText:
        unavailable.length > 0
          ? `القيم غير المتاحة (null/unavailable): ${unavailable.join("، ")}.`
          : "جميع المؤشرات المطلوبة متاحة في هذه النقطة.",
    };
  }

  return {
    availableText:
      available.length > 0
        ? available.join(", ")
        : "no numeric metrics recorded",
    unavailableText:
      unavailable.length > 0
        ? `Unavailable (null) metrics at this pixel: ${unavailable.join(", ")}.`
        : "All requested layer metrics are present at this pixel.",
  };
}

/**
 * Builds a deterministic, zero-hallucination template explanation strictly from ClickContext
 * and siteNotes when the LLM API is unreachable, unconfigured, or rate-limited.
 */
export function buildFallbackResponse(
  request: ChatRequest,
  citedSources: CitedSource[] = []
): ChatResponse {
  const language = detectLanguage(request.question, request.language);
  const personaDef = PERSONAS[request.persona];
  const ctx = request.clickContext;
  const confidenceTag = buildConfidenceTag(ctx, language);
  const citeRef =
    citedSources.length > 0 ? ` [${citedSources[0].citationTag}]` : "";

  if (!ctx) {
    const noPixelBody =
      language === "ar"
        ? `الوضع الاحتياطي المحلي (Offline Fallback): لم يتم تحديد موقع على الخريطة بعد. انقر على أي نقطة في كاليفورنيا (California) أو دلتا النيل (Nile Delta) أو الهيمالايا (Himalaya) لعرض قيم التشتت الراداري (Backscatter) والترابط (Coherence) والإزاحة (Displacement)${citeRef}.`
        : `Offline template mode: No map pixel is currently selected. Click a location in California, the Nile Delta, or the Himalaya site to inspect injected NISAR radar values${citeRef}.`;

    return {
      answer: `${noPixelBody}\n\n${confidenceTag}`,
      persona: request.persona,
      language,
      sources: citedSources,
      confidenceTag,
      isFallback: true,
    };
  }

  const { availableText, unavailableText } = summarizeValues(ctx, language);
  const shortRecordWarningEn =
    ctx.datesCount < 4 || ctx.recordDays < 45
      ? "Because datesCount or recordDays is small, this signal cannot yet be separated from atmospheric or speckle noise."
      : "Multi-date coverage supports time-series inspection, subject to coherence and local incidence-angle limits.";
  const shortRecordWarningAr =
    ctx.datesCount < 4 || ctx.recordDays < 45
      ? "نظراً لقصر السجل الزمني (Small datesCount/recordDays)، لا يمكن فصل الإشارة الجيوفيزيائية عن الضوضاء الجوية بعد."
      : "يسمح السجل متعدد التواريخ بمتابعة التغير الزمني مع مراعاة حدود الترابط (Coherence).";

  const siteWhy = safeSiteNote(ctx.siteNotes?.why);
  const siteLimits = safeSiteNote(ctx.siteNotes?.limits);

  let body = "";

  if (language === "ar") {
    const siteNameAr = SITE_LABELS_AR[ctx.siteId];
    switch (request.persona) {
      case "scientist":
        body = [
          `تحليل النقطة (${ctx.lat}, ${ctx.lon}) في موقع ${siteNameAr} بتاريخ ${ctx.date} (Track: ${ctx.track ?? "N/A"}, Direction: ${ctx.direction ?? "N/A"}, Polarizations: ${ctx.polsAvailable.join("/")})${citeRef}.`,
          `القيم المقاسة (Injected Values): ${availableText}. ${unavailableText}`,
          `ملاحظات منهجية: يجب مراعاة زاوية السقوط المحلية (Incidence Angle)، ومعايرة التضاريس (Gamma-naught)، وعتبة الترابط التداخلي (Coherence Threshold)، وافتراض ثبات نقطة المرجع (Reference Pixel)، وتأثيرات الغلاف الجوي والأيونوسفير على الموجة L-band. ${shortRecordWarningAr}${siteWhy}${siteLimits}`,
        ].join(" ");
        break;

      case "decision_maker":
        body = [
          `الخلاصة: رصد بالرادار لموقع ${siteNameAr} عند (${ctx.lat}, ${ctx.lon}) بتاريخ ${ctx.date}${citeRef}.`,
          `- القيم المسجلة: ${availableText} (${unavailableText})`,
          `- اعتبارات المتابعة: ${shortRecordWarningAr}${siteWhy}`,
          `- ما لا تخبرك به هذه البيانات (What this can't tell you): هذه القيم للمراقبة البحثية فقط وليست تقييماً معتمداً للأضرار أو أوامر إخلاء؛ يُرجع دائماً لسلطات الحماية المدنية والجهات الهندسية المختصة.${siteLimits}`,
        ].join("\n");
        break;

      case "student":
        body = [
          `خطوة بخطوة: تخيل الرادار كمصباح يدوي يرسل موجات نحو الأرض؛ الأسطح الخشنة أو الأشجار تشتت الموجات في كل الاتجاهات، بينما تغير رطوبة التربة ثابت العزل الكهربائي (Dielectric Constant) فتزيد قوة الانعكاس${citeRef}.`,
          `في موقع ${siteNameAr} بتاريخ ${ctx.date}، القيم المسجلة هي: ${availableText}. ${unavailableText} ${shortRecordWarningAr}`,
          `اختبر فهمك (Check your understanding): كيف تتغير إشارة الاستقطاب (${ctx.polsAvailable.join("/")}) إذا زادت خشونة السطح (Surface Roughness) أو رطوبته في هذه النقطة؟`,
        ].join(" ");
        break;

      case "enthusiast":
        body = [
          `من مدارها في الفضاء، ترسل مهمة NISAR نبضات رادارية تخترق السحب والظلام لترصد تغيرات سطح الأرض في ${siteNameAr} بتاريخ ${ctx.date}${citeRef}.`,
          `حقيقة مدهشة: موجات الرادار ذات النطاق (L-band) قادرة على النفاذ عبر أوراق الأشجار لرصد رطوبة التربة وحركة الجليد أو الأرض بدقة عالية.${siteWhy} ${shortRecordWarningAr}`,
        ].join(" ");
        break;
    }
  } else {
    const siteNameEn = SITE_LABELS_EN[ctx.siteId];
    switch (request.persona) {
      case "scientist":
        body = [
          `Pixel observation at (${ctx.lat}, ${ctx.lon}) in ${siteNameEn} on ${ctx.date} (Track: ${ctx.track ?? "N/A"}, Direction: ${ctx.direction ?? "N/A"}, Polarizations: ${ctx.polsAvailable.join("/")}, Active layer: ${ctx.activeLayer ?? "default"})${citeRef}.`,
          `Injected values: ${availableText}. ${unavailableText}`,
          `Caveats: Interpretation depends on local incidence-angle normalization, interferometric coherence thresholds, reference-pixel stability, and tropospheric/ionospheric L-band phase screen noise. ${shortRecordWarningEn}${siteWhy}${siteLimits}`,
        ].join(" ");
        break;

      case "decision_maker":
        body = [
          `Bottom line: Satellite radar observation at ${siteNameEn} (${ctx.lat}, ${ctx.lon}) on ${ctx.date} shows ${availableText}${citeRef}.`,
          `- Data status: ${unavailableText} ${shortRecordWarningEn}`,
          `- Planning context:${siteWhy || " Monitor multi-date trends before taking resource allocation steps."}`,
          `- What this can't tell you: These layers are unvalidated research metrics, not operational forecasts or safety directives; defer to civil protection and local engineering authorities for evacuations or structural assessments.${siteLimits}`,
        ].join("\n");
        break;

      case "student":
        body = [
          `Step 1 (Analogy): Think of radar backscatter (returned echo strength) like shining a flashlight on different surfaces—smooth water bounces light away, while rough ground or leafy branches scatter energy back toward the sensor${citeRef}.`,
          `Step 2 (Physics at this pixel): On ${ctx.date} in ${siteNameEn}, the sensor recorded ${availableText} (${unavailableText}). Two physical properties drive these values: surface roughness (geometry of leaves, ice, or soil) and the dielectric constant (how strongly water content reflects microwave energy). ${shortRecordWarningEn}`,
          `Check your understanding: Based on the available polarizations (${ctx.polsAvailable.join(", ")}), how would an increase in soil moisture or vegetation canopy roughness alter the radar echo at (${ctx.lat}, ${ctx.lon})?`,
        ].join(" ");
        break;

      case "enthusiast":
        body = [
          `Looking down at ${siteNameEn} on ${ctx.date}, radar pulses reveal how the landscape shifts beneath the sky${citeRef}.`,
          `Surprising fact: Unlike optical cameras blocked by clouds, smoke, or night, long L-band radar waves pass right through cloud cover and tree canopies to sense surface structure and moisture changes.${siteWhy} ${shortRecordWarningEn}`,
        ].join(" ");
        break;
    }
  }

  const words = body.split(/\s+/).filter(Boolean);
  const clampedBody =
    words.length > personaDef.maxWords
      ? `${words.slice(0, personaDef.maxWords).join(" ")}...`
      : body;

  return {
    answer: `${clampedBody}\n\n${confidenceTag}`,
    persona: request.persona,
    language,
    sources: citedSources,
    confidenceTag,
    isFallback: true,
  };
}