import React, { useEffect, useRef } from "react";
import {
  PERSONA_LIST,
  PERSONAS,
  savePersona,
} from "../../ai/personas";
import { PersonaId, SupportedLanguage } from "../../ai/types";

export interface PersonaSwitcherProps {
  value: PersonaId;
  onChange: (nextPersona: PersonaId) => void;
  language?: SupportedLanguage;
  disabled?: boolean;
}

/**
 * Accessible 4-persona switcher ("Scientist", "Decision Maker", "Student", "Enthusiast").
 * Persists selection in localStorage using try/catch via savePersona().
 * Supports full keyboard roving tabindex (Left/Right/Up/Down arrows) and RTL Arabic layout.
 */
export const PersonaSwitcher: React.FC<PersonaSwitcherProps> = ({
  value,
  onChange,
  language = "en",
  disabled = false,
}) => {
  const isRtl = language === "ar";
  const buttonRefs = useRef<Array<HTMLButtonElement | null>>([]);

  useEffect(() => {
    savePersona(value);
  }, [value]);

  const handleSelect = (id: PersonaId) => {
    if (disabled) {
      return;
    }
    savePersona(id);
    onChange(id);
  };

  const handleKeyDown = (
    event: React.KeyboardEvent<HTMLButtonElement>,
    index: number
  ) => {
    if (disabled) {
      return;
    }
    const count = PERSONA_LIST.length;
    let nextIndex: number | null = null;

    if (event.key === "ArrowRight" || event.key === "ArrowDown") {
      event.preventDefault();
      nextIndex = isRtl
        ? (index - 1 + count) % count
        : (index + 1) % count;
    } else if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
      event.preventDefault();
      nextIndex = isRtl
        ? (index + 1) % count
        : (index - 1 + count) % count;
    } else if (event.key === "Home") {
      event.preventDefault();
      nextIndex = 0;
    } else if (event.key === "End") {
      event.preventDefault();
      nextIndex = count - 1;
    }

    if (nextIndex !== null) {
      const targetPersona = PERSONA_LIST[nextIndex];
      handleSelect(targetPersona.id);
      buttonRefs.current[nextIndex]?.focus();
    }
  };

  const activeDef = PERSONAS[value];

  return (
    <div
      dir={isRtl ? "rtl" : "ltr"}
      className="persona-switcher"
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "0.5rem",
        padding: "0.75rem",
        borderRadius: "0.5rem",
        backgroundColor: "#0f172a",
        border: "1px solid #1e293b",
        color: "#f8fafc",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          fontSize: "0.75rem",
          fontWeight: 600,
          textTransform: "uppercase",
          letterSpacing: "0.05em",
          color: "#94a3b8",
        }}
      >
        <span id="persona-switcher-label">
          {isRtl ? "نمط الشرح (Explanation Persona)" : "Explanation Persona"}
        </span>
        <span>
          {isRtl
            ? `الحد الأقصى: ${activeDef.maxWords} كلمة`
            : `Max ~${activeDef.maxWords} words`}
        </span>
      </div>

      <div
        role="radiogroup"
        aria-labelledby="persona-switcher-label"
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(125px, 1fr))",
          gap: "0.375rem",
        }}
      >
        {PERSONA_LIST.map((persona, idx) => {
          const isSelected = persona.id === value;
          return (
            <button
              key={persona.id}
              ref={(el) => {
                buttonRefs.current[idx] = el;
              }}
              type="button"
              role="radio"
              aria-checked={isSelected}
              tabIndex={isSelected ? 0 : -1}
              disabled={disabled}
              onClick={() => handleSelect(persona.id)}
              onKeyDown={(e) => handleKeyDown(e, idx)}
              style={{
                padding: "0.5rem 0.625rem",
                borderRadius: "0.375rem",
                border: isSelected
                  ? "1px solid #38bdf8"
                  : "1px solid #334155",
                backgroundColor: isSelected ? "#0284c7" : "#1e293b",
                color: isSelected ? "#ffffff" : "#cbd5e1",
                fontWeight: isSelected ? 600 : 500,
                fontSize: "0.8125rem",
                cursor: disabled ? "not-allowed" : "pointer",
                textAlign: "center",
                transition: "background-color 120ms ease, border-color 120ms ease",
              }}
            >
              {isRtl ? persona.labelAr : persona.label}
            </button>
          );
        })}
      </div>

      <p
        aria-live="polite"
        style={{
          margin: 0,
          fontSize: "0.75rem",
          lineHeight: 1.4,
          color: "#cbd5e1",
        }}
      >
        {isRtl ? activeDef.uiDescriptionAr : activeDef.uiDescription}
      </p>
    </div>
  );
};

export default PersonaSwitcher;