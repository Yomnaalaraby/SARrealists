# External References & Official Data Sources

Generated automatically from `scripts/sources.yaml` for the **Dancing with the SARs** NASA Space Apps Challenge submission.

## Ingested Official NISAR & SAR Documentation

1. **NASA NISAR Mission - Societal Benefits Overview** (`nasa_nisar_societal_benefits`)
   - **URL / Path**: https://science.nasa.gov/mission/nisar/societal-benefits/
   - **Attribution / License**: NASA / Jet Propulsion Laboratory (JPL) - California Institute of Technology (Public Domain / 17 U.S.C. 105)
   - **Status**: Ingested / Enabled

2. **NISAR Applications White Paper: Smart Firefighting - Fire Management** (`nasa_nisar_wp_fire_management`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISAR_Applications_Fire_Management1.pdf
   - **Attribution / License**: NASA / JPL-Caltech (2017) - NISAR Societal Benefits White Paper Series
   - **Status**: Ingested / Enabled

3. **NISAR Applications White Paper: Monitoring Forest Disturbance and Timber** (`nasa_nisar_wp_forest_disturbance`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISAR_Applications_Timber_and_Forest_Disturbance.pdf
   - **Attribution / License**: NASA / JPL-Caltech (2017) - NISAR Societal Benefits White Paper Series
   - **Status**: Ingested / Enabled

4. **NISAR Applications White Paper: Making Large Scale Stewardship of Forest Resources a Reality** (`nasa_nisar_wp_forest_resources`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISAR_Applications_Forest_Resources1.pdf
   - **Attribution / License**: NASA / JPL-Caltech (2017) - NISAR Societal Benefits White Paper Series
   - **Status**: Ingested / Enabled

5. **NISAR Science Overview: Monitoring and Managing Our Terrestrial Ecosystems & Agriculture** (`nasa_nisar_wp_ecosystems_ag`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NASA_ISRO_SAR_Mission_Ecosystems1.pdf
   - **Attribution / License**: NASA / JPL-Caltech (JPL 400-1564 Rev. 1)
   - **Status**: Ingested / Enabled

6. **NISAR Science Overview: Water: Sustaining Life - Groundwater Depletion & Land Subsidence** (`nasa_nisar_wp_water_subsidence`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NASA_ISRO_SAR_Mission_Water1.pdf
   - **Attribution / License**: NASA / JPL-Caltech (JPL 400-1598 Rev. 1)
   - **Status**: Ingested / Enabled

7. **NISAR Applications White Paper: Coastal Regions and Ocean Moods (Coastal Land Loss & Deltas)** (`nasa_nisar_wp_coastal_issues`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISAR_Applications_Coastal_Issues1.pdf
   - **Attribution / License**: NASA / JPL-Caltech (2017) - NISAR Societal Benefits White Paper Series
   - **Status**: Ingested / Enabled

8. **NISAR Applications White Paper: Glaciers, Ice Sheets, and the Oceans** (`nasa_nisar_wp_glaciers_ice_sheets`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISAR_Applications_Ice_Sheets_Glaciers_Oceans.pdf
   - **Attribution / License**: NASA / JPL-Caltech (2017) - NISAR Societal Benefits White Paper Series
   - **Status**: Ingested / Enabled

9. **NISAR Science Overview: Understanding Earth's Cold Regions (Cryosphere & Glaciers)** (`nasa_nisar_wp_cold_regions`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NASA_ISRO_SAR_Mission_ColdRegions1.pdf
   - **Attribution / License**: NASA / JPL-Caltech - NISAR Cryosphere Brochure
   - **Status**: Ingested / Enabled

10. **NISAR Applications White Paper: Rapid Damage Assessment After Natural Disasters** (`nasa_nisar_wp_damage_mapping`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISAR_DamageMapping.pdf
   - **Attribution / License**: NASA / JPL-Caltech (2019) - NISAR Societal Benefits White Paper Series
   - **Status**: Ingested / Enabled

11. **NISAR Applications White Paper: Terrestrial Permafrost & Post-Fire Subsidence** (`nasa_nisar_wp_permafrost_fire`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISARApplications_Permafrost1.pdf
   - **Attribution / License**: NASA / JPL-Caltech (2019) - NISAR Societal Benefits White Paper Series
   - **Status**: Ingested / Enabled

12. **ASF OpenSARLab NISAR Cookbook** (`asf_nisar_cookbook_home`)
   - **URL / Path**: https://asfopensarlab.github.io/NISAR_Cookbook/
   - **Attribution / License**: Alaska Satellite Facility (ASF) OpenSARLab - BSD-3-Clause License
   - **Status**: Ingested / Enabled

13. **ASF NISAR Data User Guide - Overview** (`asf_nisar_docs_home`)
   - **URL / Path**: https://nisar-docs.asf.alaska.edu/
   - **Attribution / License**: Alaska Satellite Facility (ASF) / NASA Earthdata
   - **Status**: Ingested / Enabled

14. **ASF NISAR Data User Guide - White Papers and Mission Documents Index** (`asf_nisar_docs_documents`)
   - **URL / Path**: https://nisar-docs.asf.alaska.edu/documents/
   - **Attribution / License**: Alaska Satellite Facility (ASF) / NASA Earthdata
   - **Status**: Ingested / Enabled

15. **ASF NISAR Data User Guide - Product Specifications** (`asf_nisar_docs_product_specs`)
   - **URL / Path**: https://nisar-docs.asf.alaska.edu/product-specification/
   - **Attribution / License**: Alaska Satellite Facility (ASF) / NASA Earthdata
   - **Status**: Ingested / Enabled

16. **ASF NISAR Data User Guide - Data Processing Algorithms (ATBDs)** (`asf_nisar_docs_atbd`)
   - **URL / Path**: https://nisar-docs.asf.alaska.edu/atbd/
   - **Attribution / License**: Alaska Satellite Facility (ASF) / NASA Earthdata
   - **Status**: Ingested / Enabled

17. **NASA NISAR Mission Official Overview** (`nasa_nisar_mission_home`)
   - **URL / Path**: https://science.nasa.gov/mission/nisar/
   - **Attribution / License**: NASA / Jet Propulsion Laboratory (JPL) / ISRO
   - **Status**: Ingested / Enabled

18. **NASA NISAR Data Overview & Sample Product Suite** (`nasa_nisar_data_overview`)
   - **URL / Path**: https://science.nasa.gov/mission/nisar/data/
   - **Attribution / License**: NASA / Jet Propulsion Laboratory (JPL)
   - **Status**: Ingested / Enabled

19. **NASA-ISRO SAR (NISAR) Mission Science Users' Handbook Landing Page** (`nasa_nisar_handbook_page`)
   - **URL / Path**: https://science.nasa.gov/mission/nisar/nisar-handbook/
   - **Attribution / License**: NASA Jet Propulsion Laboratory (2025, DOI: 10.48577/jpl.UD4HV3)
   - **Status**: Ingested / Enabled

20. **NASA-ISRO SAR (NISAR) Mission Science Users' Handbook (First Edition PDF)** (`nasa_nisar_handbook_pdf_v1`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISAR_FINAL_9-6-19.pdf
   - **Attribution / License**: NASA Jet Propulsion Laboratory (2019) - NISAR Science Users' Handbook
   - **Status**: Ingested / Enabled

21. **NISAR Mission Utilization Plan (JPL D-102207)** (`nasa_nisar_utilization_plan`)
   - **URL / Path**: https://assets.science.nasa.gov/content/dam/science/missions/nisar/nisar-jpl/pdf/NISAR_Utilization_Plan.pdf
   - **Attribution / License**: NASA Jet Propulsion Laboratory (2018, JPL D-102207)
   - **Status**: Ingested / Enabled

22. **NISAR Level-2 Geocoded Polarimetric Covariance (GCOV) Product Specification (JPL D-102274)** (`nisar_spec_l2_gcov`)
   - **URL / Path**: https://nisar.asf.earthdatacloud.nasa.gov/NISAR-SAMPLE-DATA/DOCS/NISAR_D-102274_RevE_NASA_SDS_Product_Specification_L2_GCOV_Nov8_2024_w-sigs.pdf
   - **Attribution / License**: Shiroma, G. H. X. (2024). NASA SDS Product Specification JPL D-102274, NASA JPL
   - **Status**: Ingested / Enabled

23. **NISAR Level-2 Geocoded Unwrapped Interferogram (GUNW) Product Specification (JPL D-102272)** (`nisar_spec_l2_gunw`)
   - **URL / Path**: https://nisar.asf.earthdatacloud.nasa.gov/NISAR-SAMPLE-DATA/DOCS/NISAR_D-102272_RevE_NASA_SDS_Product_Specification_L2_GUNW_Nov8_2024_w-sigs.pdf
   - **Attribution / License**: Brancato, V., Jung, J., Huang, X., & Fattahi, H. (2024). NASA SDS Product Specification JPL D-102272, NASA JPL
   - **Status**: Ingested / Enabled

24. **NISAR Level-2 Geocoded Pixel Offsets (GOFF) Product Specification (JPL D-105010)** (`nisar_spec_l2_goff`)
   - **URL / Path**: https://nisar.asf.earthdatacloud.nasa.gov/NISAR-SAMPLE-DATA/DOCS/NISAR_D-105010_RevC_NASA_SDS_Product_Specification_L2_GOFF_Nov8_2024_w-sigs.pdf
   - **Attribution / License**: Brancato, V., Jung, J., & Huang, X. (2024). NASA SDS Product Specification JPL D-105010, NASA JPL
   - **Status**: Ingested / Enabled

25. **NISAR Level-3 Soil Moisture (SME2) Product Specification (JPL D-107677)** (`nisar_spec_l3_sme2`)
   - **URL / Path**: https://nisar.asf.earthdatacloud.nasa.gov/NISAR-SAMPLE-DATA/DOCS/NISAR_D-107677_RevC_NASA_SDS_Product_Specification_L3_SME2_Nov8_2024_w-sigs.pdf
   - **Attribution / License**: Huang, X., & Chan, S. K. (2024). NASA SDS Product Specification JPL D-107677, NASA JPL
   - **Status**: Ingested / Enabled

26. **NISAR L1 and L2 Algorithm Theoretical Basis Document (ATBD JPL D-95677)** (`nisar_atbd_l1_l2`)
   - **URL / Path**: https://nisar.asf.earthdatacloud.nasa.gov/NISAR-SAMPLE-DATA/DOCS/NISAR_D-95677_NASA_L1_L2_ATBD_20231112_R3.4_w-sigs.pdf
   - **Attribution / License**: NISAR Algorithm Development Team (2023). Techreport JPL D-95677 Rev 3.4, NASA JPL
   - **Status**: Ingested / Enabled

27. **NISAR L3 Soil Moisture Data Product Algorithm Theoretical Basis Document (ATBD JPL D-107679)** (`nisar_atbd_l3_soil_moisture`)
   - **URL / Path**: https://nisar.asf.earthdatacloud.nasa.gov/NISAR-SAMPLE-DATA/DOCS/NISAR_D-107679_L3SM_ATBD_R3.3_20230428_w-sigs.pdf
   - **Attribution / License**: NISAR Soil Moisture Science Team (2023). Techreport JPL D-107679 Rev 3.3, NASA JPL
   - **Status**: Ingested / Enabled

28. **TODO: NASA-ISRO SAR (NISAR) Mission Science Users' Handbook (Second Edition, Oct 2025, 92.26 MB PDF)** (`todo_nisar_handbook_2nd_ed_pdf`)
   - **URL / Path**: TODO_VERIFY_DIRECT_PDF_URL_FROM_https://science.nasa.gov/mission/nisar/nisar-handbook/
   - **Attribution / License**: NISAR (2025). NASA-ISRO SAR Mission Science Users' Handbook, Second Edition. NASA JPL. DOI: 10.48577/jpl.UD4HV3
   - **Status**: Reference Only
   - **Notes**: Landing page is verified and ingested above; inspect page download link to replace URL if full 92 MB PDF ingestion is desired.

29. **TODO: NISAR Applications White Paper: Mountain Glaciers and Snow Hydrology (2023)** (`todo_nisar_wp_mountain_glaciers_snow_hydrology`)
   - **URL / Path**: TODO_VERIFY_DIRECT_PDF_URL_FROM_https://nisar-docs.asf.alaska.edu/documents/
   - **Attribution / License**: NASA / JPL-Caltech (2023) - NISAR Application White Paper
   - **Status**: Reference Only
   - **Notes**: Listed on nisar-docs.asf.alaska.edu/documents/ and science.nasa.gov/mission/nisar/documents/; verify exact assets.science.nasa.gov PDF filename before enabling.

30. **TODO: NISAR Applications White Paper: Subsidence (2017 2-page brief)** (`todo_nisar_wp_subsidence_2017`)
   - **URL / Path**: TODO_VERIFY_DIRECT_PDF_URL_FROM_https://nisar-docs.asf.alaska.edu/documents/
   - **Attribution / License**: NASA / JPL-Caltech (2017) - NISAR Application White Paper
   - **Status**: Reference Only
   - **Notes**: Groundwater subsidence brochure (NASA_ISRO_SAR_Mission_Water1.pdf) is enabled above; verify exact filename for the standalone 2017 Subsidence PDF on science.nasa.gov/mission/nisar/documents/.

31. **NASA Space Apps Challenge Statement: Dancing with the SARs** (`local_space_apps_challenge`)
   - **URL / Path**: docs/challenge.md
   - **Attribution / License**: NASA Space Apps Challenge Official Challenge Statement
   - **Status**: Ingested / Enabled

32. **Dancing with the SARs: Team Processing Pipeline, RVI/InSAR Methods, and Limitations** (`local_team_methods`)
   - **URL / Path**: docs/methods.md
   - **Attribution / License**: Dancing with the SARs Team Methodology & Limitations Documentation
   - **Status**: Ingested / Enabled
